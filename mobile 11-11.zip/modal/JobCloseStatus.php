<?php
require_once __DIR__.'/../util/initialize.php';

class JobCloseStatus extends DatabaseObject{
    protected static $table_name="job_close_status";
    protected static $db_fields=array(); 
    protected static $db_fk=array();
    
//    public $id;
//    public $name;
}

?>