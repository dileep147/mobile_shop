-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 09, 2020 at 07:43 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mobile_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity`
--

CREATE TABLE `activity` (
  `id` int(11) NOT NULL,
  `date_time` datetime DEFAULT NULL,
  `description` text,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `activity`
--

INSERT INTO `activity` (`id`, `date_time`, `description`, `user_id`) VALUES
(1, '2020-03-14 07:49:01', 'Login - \'admin\'', 1),
(2, '2020-03-14 07:51:36', 'Login - \'admin\'', 1),
(3, '2020-03-14 08:23:51', 'Login - \'admin\'', 1),
(4, '2020-03-14 09:44:57', 'Login - \'admin\'', 1),
(5, '2020-03-21 11:11:47', 'Login - \'admin\'', 1),
(6, '2020-03-25 13:44:07', 'Login - \'admin\'', 1),
(7, '2020-03-25 13:45:09', 'Logout - \'admin\'', 1),
(8, '2020-05-05 13:48:34', 'Login - \'admin\'', 1),
(9, '2020-05-08 11:06:39', 'Login - \'admin\'', 1),
(10, '2020-05-14 09:38:17', 'Login - \'admin\'', 1),
(11, '2020-05-22 13:42:32', 'Login - \'admin\'', 1),
(12, '2020-05-22 14:40:52', 'Deliverer - saved : 1', 1),
(13, '2020-07-25 22:25:55', 'Login - \'admin\'', 1),
(14, '2020-07-25 22:33:32', 'Category saved - test', 1),
(15, '2020-07-25 22:33:39', 'Category deleted - test', 1),
(16, '2020-07-25 22:34:48', 'Logout - \'admin\'', 1),
(17, '2020-07-25 22:35:17', 'Login - \'admin\'', 1),
(18, '2020-07-26 09:42:39', 'Logout - \'admin\'', 1),
(19, '2020-08-21 12:57:26', 'Login - \'admin\'', 1),
(20, '2020-08-21 14:54:22', 'Logout - \'admin\'', 1),
(21, '2020-08-21 14:54:25', 'Login - \'admin\'', 1),
(22, '2020-08-21 18:26:58', 'Login - \'admin\'', 1),
(23, '2020-08-21 19:14:29', 'Logout - \'admin\'', 1),
(24, '2020-08-21 19:14:31', 'Login - \'admin\'', 1),
(25, '2020-08-21 19:33:13', 'DeviceFault saved - ', 1),
(26, '2020-08-21 19:39:55', 'PossibleSolution saved - ', 1),
(27, '2020-08-21 19:40:48', 'PossibleSolution deleted - ', 1),
(28, '2020-08-21 19:40:53', 'DeviceFault deleted - ', 1),
(29, '2020-08-21 19:46:49', 'CollectedAccessories saved - ', 1),
(30, '2020-08-21 19:46:56', 'CollectedAccessories deleted - ', 1),
(31, '2020-08-21 20:44:22', 'DeviceFault saved - ', 1),
(32, '2020-08-21 20:46:31', 'DeviceFault saved - ', 1),
(33, '2020-08-21 20:47:23', 'PossibleSolution saved - ', 1),
(34, '2020-08-21 20:48:54', 'CollectedAccessories saved - ', 1),
(35, '2020-08-21 20:49:01', 'CollectedAccessories saved - ', 1),
(36, '2020-08-21 22:10:34', 'Logout - \'admin\'', 1),
(37, '2020-08-21 22:10:37', 'Login - \'admin\'', 1),
(38, '2020-08-21 22:26:54', 'Logout - \'admin\'', 1),
(39, '2020-08-22 14:59:11', 'Logout - \'admin\'', 1),
(40, '2020-08-22 14:59:13', 'Login - \'admin\'', 1),
(41, '2020-08-22 16:09:23', 'DeviceModel saved - ', 1),
(42, '2020-08-22 16:10:19', 'DeviceModel deleted - ', 1),
(43, '2020-08-22 16:10:29', 'DeviceModel saved - ', 1),
(44, '2020-08-22 16:14:58', 'DeviceModel updated - ', 1),
(45, '2020-08-22 16:15:04', 'DeviceModel updated - ', 1),
(46, '2020-08-22 16:15:06', 'DeviceModel deleted - ', 1),
(47, '2020-08-22 16:15:17', 'DeviceModel saved - ', 1),
(48, '2020-08-22 16:19:34', 'Batch updated - ', 1),
(49, '2020-08-22 16:21:17', 'Batch updated - ', 1),
(50, '2020-08-22 16:22:48', 'Batch updated - ', 1),
(51, '2020-08-22 16:23:02', 'DeviceModel updated - ', 1),
(52, '2020-08-26 08:09:23', 'Login - \'admin\'', 1),
(53, '2020-09-01 14:07:26', 'Login - \'admin\'', 1),
(54, '2020-09-01 14:55:53', 'Logout - \'admin\'', 1),
(55, '2020-09-01 14:58:54', 'Login - \'admin\'', 1),
(56, '2020-09-01 16:16:56', 'Logout - \'admin\'', 1),
(57, '2020-09-01 16:17:23', 'Login - \'admin\'', 1),
(58, '2020-09-01 18:00:19', 'Logout - \'admin\'', 1),
(59, '2020-09-01 18:00:22', 'Login - \'admin\'', 1),
(60, '2020-09-01 18:52:26', 'Device Repair - saved', 1),
(61, '2020-09-01 18:55:34', 'Device Repair - saved', 1),
(62, '2020-09-01 19:10:09', 'Device Repair - saved', 1),
(63, '2020-09-01 19:10:46', 'Device Repair - saved', 1),
(64, '2020-09-01 19:11:02', 'Device Repair - saved', 1),
(65, '2020-09-01 19:15:02', 'Device Repair - saved', 1),
(66, '2020-09-01 19:15:15', 'Device Repair - saved', 1),
(67, '2020-09-01 19:22:47', 'Device Repair - saved', 1),
(68, '2020-09-01 19:28:05', 'Device Repair - updated:', 1),
(69, '2020-09-01 19:28:15', 'Device Repair - updated:', 1),
(70, '2020-09-01 19:28:22', 'Device Repair - updated:', 1),
(71, '2020-09-01 19:30:03', 'Repair - deleted:', 1),
(72, '2020-09-01 19:30:47', 'Device Repair - saved', 1),
(73, '2020-09-01 19:31:01', 'Device Repair - updated:', 1),
(74, '2020-09-02 14:16:51', 'Logout - \'admin\'', 1),
(75, '2020-09-02 14:16:55', 'Login - \'admin\'', 1),
(76, '2020-09-02 15:26:32', 'brand saved - ', 1),
(77, '2020-09-02 15:30:06', 'brand saved - ', 1),
(78, '2020-09-02 15:44:37', 'brand saved - ', 1),
(79, '2020-09-02 16:24:42', 'brand saved - ', 1),
(80, '2020-09-02 16:49:01', 'Batch saved - ', 1),
(81, '2020-09-02 18:45:50', 'Login - \'admin\'', 1),
(82, '2020-09-02 18:47:14', 'Batch saved - ', 1),
(83, '2020-09-02 18:47:52', 'Batch saved - ', 1),
(84, '2020-09-02 18:53:14', 'Batch saved - ', 1),
(85, '2020-09-02 18:58:22', 'Location Number - updated : ', 1),
(86, '2020-09-02 19:00:14', 'Location Number - updated : ', 1),
(87, '2020-09-02 19:00:25', 'brand saved - ', 1),
(88, '2020-09-02 19:09:17', 'Location Number - updated : ', 1),
(89, '2020-09-02 19:09:38', 'brand saved', 1),
(90, '2020-09-02 19:10:11', 'Role - deleted : hvj', 1),
(91, '2020-09-02 19:10:16', 'Role - deleted : ffds', 1),
(92, '2020-09-02 19:10:20', 'Role - deleted : ghn', 1),
(93, '2020-09-02 19:10:32', 'Brand - updated : ', 1),
(94, '2020-09-02 19:10:44', 'Brand - updated : ', 1),
(95, '2020-09-02 19:29:36', 'RepairStatus saved', 1),
(96, '2020-09-02 19:30:57', 'RepairStatus - updated : ', 1),
(97, '2020-09-02 19:40:14', 'Login - \'admin\'', 1),
(98, '2020-09-02 21:45:51', 'Login - \'admin\'', 1),
(99, '2020-09-02 21:47:27', 'brand saved', 1),
(100, '2020-09-03 09:57:44', 'Login - \'admin\'', 1),
(101, '2020-09-03 13:23:07', 'Login - \'admin\'', 1),
(102, '2020-09-03 17:38:02', 'Login - \'admin\'', 1),
(103, '2020-09-03 18:14:46', 'Login - \'admin\'', 1),
(104, '2020-09-03 21:09:09', 'Login - \'admin\'', 1),
(105, '2020-09-03 22:00:20', 'Login - \'admin\'', 1),
(106, '2020-09-04 17:58:22', 'Login - \'admin\'', 1),
(107, '2020-09-04 19:56:45', 'Login - \'admin\'', 1),
(108, '2020-09-04 23:20:53', 'Login - \'admin\'', 1),
(109, '2020-09-06 01:16:12', 'Login - \'admin\'', 1),
(110, '2020-09-06 11:21:41', 'Login - \'admin\'', 1),
(111, '2020-09-06 16:00:22', 'Login - \'admin\'', 1),
(112, '2020-09-07 08:33:08', 'Login - \'admin\'', 1),
(113, '2020-09-07 09:31:14', 'Login - \'admin\'', 1),
(114, '2020-09-07 10:32:53', 'RepairStatus saved', 1),
(115, '2020-09-07 12:40:32', 'Logout - \'admin\'', 1),
(116, '2020-09-07 12:40:40', 'Login - \'admin\'', 1),
(117, '2020-09-07 13:26:51', 'Device Repair - saved', 1),
(118, '2020-09-07 13:28:53', 'Device Repair - saved', 1),
(119, '2020-09-07 13:35:15', 'Device Repair - saved', 1),
(120, '2020-09-07 13:40:39', 'Device Repair - saved', 1),
(121, '2020-09-07 13:53:06', 'Device Repair - saved', 1),
(122, '2020-09-07 13:53:29', 'Device Repair - saved', 1),
(123, '2020-09-07 13:54:19', 'Device Repair - saved', 1),
(124, '2020-09-07 13:55:49', 'Device Repair - saved', 1),
(125, '2020-09-07 14:00:25', 'Device Repair - saved', 1),
(126, '2020-09-07 14:03:12', 'Device Repair - saved', 1),
(127, '2020-09-07 14:04:30', 'Device Repair - saved', 1),
(128, '2020-09-07 14:31:44', 'Device Repair - saved', 1),
(129, '2020-09-07 16:08:01', 'Logout - \'admin\'', 1),
(130, '2020-09-07 16:08:08', 'Login - \'admin\'', 1),
(131, '2020-09-07 16:13:09', 'Device Repair - saved', 1),
(132, '2020-09-07 17:00:04', 'Device Repair - saved', 1),
(133, '2020-09-07 17:02:12', 'Device Repair - saved', 1),
(134, '2020-09-07 19:48:46', 'Login - \'admin\'', 1),
(135, '2020-09-08 10:31:13', 'Login - \'admin\'', 1),
(136, '2020-09-08 19:28:22', 'Login - \'admin\'', 1),
(137, '2020-09-08 19:37:47', 'Device Repair - saved', 1),
(138, '2020-09-08 19:39:29', 'Login - \'admin\'', 1),
(139, '2020-09-08 19:39:42', 'brand saved', 1),
(140, '2020-09-08 20:56:35', 'Login - \'admin\'', 1),
(141, '2020-09-08 22:05:17', 'Login - \'admin\'', 1),
(142, '2020-09-09 11:59:29', 'Login - \'admin\'', 1),
(143, '2020-09-09 20:45:08', 'Login - \'admin\'', 1),
(144, '2020-09-10 10:02:58', 'Login - \'admin\'', 1),
(145, '2020-09-10 10:50:06', 'Device Repair - saved', 1),
(146, '2020-09-10 10:51:23', 'Device Repair - saved', 1),
(147, '2020-09-10 10:53:00', 'Device Repair - saved', 1),
(148, '2020-09-10 10:54:40', 'Device Repair - saved', 1),
(149, '2020-09-10 10:56:55', 'Device Repair - saved', 1),
(150, '2020-09-10 11:29:48', 'Logout - \'admin\'', 1),
(151, '2020-09-10 11:29:52', 'Login - \'admin\'', 1),
(152, '2020-09-11 08:52:50', 'Login - \'admin\'', 1),
(153, '2020-09-11 09:22:55', 'Device Repair - saved', 1),
(154, '2020-09-11 09:38:32', 'Device Repair - saved', 1),
(155, '2020-09-11 09:42:42', 'Device Repair - saved', 1),
(156, '2020-09-11 10:04:23', 'Device Repair - saved', 1),
(157, '2020-09-11 11:07:08', 'DeviceFault saved - ', 1),
(158, '2020-09-11 11:53:11', 'Logout - \'admin\'', 1),
(159, '2020-09-11 11:53:15', 'Login - \'admin\'', 1),
(160, '2020-09-11 11:55:02', 'Device Repair - saved', 1),
(161, '2020-09-11 12:11:54', 'Device Repair - saved', 1),
(162, '2020-09-11 12:16:20', 'Device Repair - saved', 1),
(163, '2020-09-11 12:24:08', 'Repair - deleted:', 1),
(164, '2020-09-11 12:49:08', 'Device Repair - saved', 1),
(165, '2020-09-11 12:54:05', 'Device Repair - saved', 1),
(166, '2020-09-11 12:57:42', 'Device Repair - updated:', 1),
(167, '2020-09-11 13:01:23', 'Device Repair - updated:', 1),
(168, '2020-09-11 13:31:24', 'Device Repair - updated:', 1),
(169, '2020-09-11 13:32:19', 'Device Repair - updated:', 1),
(170, '2020-09-11 13:41:36', 'Device Repair - updated:', 1),
(171, '2020-09-11 13:55:02', 'Device Repair - updated:', 1),
(172, '2020-09-11 14:07:44', 'Device Repair - saved', 1),
(173, '2020-09-11 16:04:53', 'Logout - \'admin\'', 1),
(174, '2020-09-11 16:04:58', 'Login - \'admin\'', 1),
(175, '2020-09-11 22:17:56', 'Login - \'admin\'', 1),
(176, '2020-09-12 08:23:17', 'Login - \'admin\'', 1),
(177, '2020-09-12 08:48:43', 'Device Repair - saved', 1),
(178, '2020-09-12 08:50:02', 'Repair - deleted:', 1),
(179, '2020-09-12 08:56:04', 'Device Repair - saved', 1),
(180, '2020-09-12 09:07:43', 'Device Repair - updated:', 1),
(181, '2020-09-12 09:22:10', 'Device Repair - saved', 1),
(182, '2020-09-12 09:22:52', 'Device Repair - updated:', 1),
(183, '2020-09-12 09:25:42', 'Device Repair - saved', 1),
(184, '2020-09-12 09:26:37', 'Device Repair - updated:', 1),
(185, '2020-09-12 09:27:26', 'Device Repair - updated:', 1),
(186, '2020-09-12 09:32:28', 'Device Repair - updated:', 1),
(187, '2020-09-12 11:30:30', 'Logout - \'admin\'', 1),
(188, '2020-09-12 11:30:35', 'Login - \'admin\'', 1),
(189, '2020-09-12 11:56:36', 'JobCloseStatus - saved : ', 1),
(190, '2020-09-12 12:08:18', 'JobCloseStatus - saved : ', 1),
(191, '2020-09-12 12:09:05', 'JobCloseStatus - updated : ', 1),
(192, '2020-09-12 12:13:25', 'JobCloseStatus - deleted : Dileep', 1),
(193, '2020-09-12 12:13:42', 'JobCloseStatus - updated : ', 1),
(194, '2020-09-12 12:56:16', 'Logout - \'admin\'', 1),
(195, '2020-09-12 12:56:20', 'Login - \'admin\'', 1),
(196, '2020-09-12 12:56:39', 'JobCloseStatus - saved : ', 1),
(197, '2020-09-12 12:58:25', 'JobCloseStatus - deleted : qqq', 1),
(198, '2020-09-12 12:59:59', 'JobCloseStatus - saved : ', 1),
(199, '2020-09-12 13:02:33', 'JobCloseStatus - updated : ', 1),
(200, '2020-09-12 14:26:04', 'JobClose - saved : ', 1),
(201, '2020-09-12 14:56:14', 'JobClose - saved : ', 1),
(202, '2020-09-12 14:58:23', 'JobClose - saved : ', 1),
(203, '2020-09-12 15:07:38', 'JobClose - deleted : ', 1),
(204, '2020-09-12 15:07:59', 'JobClose - updated : ', 1),
(205, '2020-09-13 09:02:30', 'Login - \'admin\'', 1),
(206, '2020-09-13 09:35:29', 'PaymentClose - saved : ', 1),
(207, '2020-09-13 09:36:15', 'PaymentClose - saved : ', 1),
(208, '2020-09-13 09:37:40', 'PaymentClose - saved : ', 1),
(209, '2020-09-13 09:38:58', 'PaymentClose - saved : ', 1),
(210, '2020-09-13 09:57:32', 'PaymentClose - saved : ', 1),
(211, '2020-09-13 09:57:43', 'PaymentClose - saved : ', 1),
(212, '2020-09-13 09:59:57', 'PaymentClose - saved : ', 1),
(213, '2020-09-13 10:01:07', 'PaymentClose - saved : ', 1),
(214, '2020-09-13 10:24:43', 'PaymentClose - saved : ', 1),
(215, '2020-09-13 10:34:53', 'PaymentClose - saved : ', 1),
(216, '2020-09-13 10:36:39', 'PaymentClose - deleted : ', 1),
(217, '2020-09-13 10:37:44', 'PaymentClose - updated : ', 1),
(218, '2020-09-13 10:47:45', 'PaymentClose - saved : ', 1),
(219, '2020-09-13 10:54:39', 'PaymentClose - updated : ', 1),
(220, '2020-09-13 10:55:47', 'PaymentClose - updated : ', 1),
(221, '2020-09-13 10:56:14', 'JobClose - updated : ', 1),
(222, '2020-09-13 10:59:05', 'PaymentClose - saved : ', 1),
(223, '2020-09-13 10:59:37', 'PaymentClose - saved : ', 1),
(224, '2020-09-13 11:00:38', 'PaymentClose - saved : ', 1),
(225, '2020-09-13 11:02:19', 'PaymentClose - saved : ', 1),
(226, '2020-09-13 11:03:19', 'DeviceFault saved - ', 1),
(227, '2020-09-13 11:06:25', 'JobCloseStatus - saved : ', 1),
(228, '2020-09-13 11:07:39', 'JobCloseStatus - saved : ', 1),
(229, '2020-09-13 11:07:57', 'JobClose - saved : ', 1),
(230, '2020-09-13 11:09:24', 'JobCloseStatus - saved : ', 1),
(231, '2020-09-13 11:09:46', 'JobCloseStatus - deleted : qqqqqqq', 1),
(232, '2020-09-13 11:10:59', 'JobCloseStatus - deleted : pipipi', 1),
(233, '2020-09-13 11:11:16', 'JobCloseStatus - saved : ', 1),
(234, '2020-09-13 11:11:39', 'JobClose - saved : ', 1),
(235, '2020-09-13 11:12:06', 'DeviceFault saved - ', 1),
(236, '2020-09-13 11:14:06', 'JobClose - saved : ', 1),
(237, '2020-09-13 11:18:04', 'JobCloseStatus - saved : ', 1),
(238, '2020-09-13 11:18:57', 'JobCloseStatus - saved : ', 1),
(239, '2020-09-13 11:20:03', 'JobCloseStatus - saved : ', 1),
(240, '2020-09-13 11:20:12', 'JobCloseStatus - deleted : dfgsgsgbwsg', 1),
(241, '2020-09-13 11:20:24', 'JobCloseStatus - updated : ', 1),
(242, '2020-09-13 11:20:48', 'JobClose - saved : ', 1),
(243, '2020-09-13 11:21:10', 'JobClose - saved : ', 1),
(244, '2020-09-13 11:21:20', 'JobClose - deleted : ', 1),
(245, '2020-09-13 11:28:06', 'PaymentClose - saved : ', 1),
(246, '2020-09-13 11:28:24', 'PaymentClose - saved : ', 1),
(247, '2020-09-13 11:28:34', 'PaymentClose - deleted : ', 1),
(248, '2020-09-13 11:28:44', 'PaymentClose - updated : ', 1),
(249, '2020-09-14 11:06:31', 'Login - \'admin\'', 1),
(250, '2020-09-14 13:23:23', 'Logout - \'admin\'', 1),
(251, '2020-09-14 13:23:26', 'Login - \'admin\'', 1),
(252, '2020-09-15 10:06:08', 'Login - \'admin\'', 1),
(253, '2020-09-15 10:09:15', 'DeviceFault - deleted : ', 1),
(254, '2020-09-15 10:12:56', 'Batch updated - ', 1),
(255, '2020-09-15 10:13:08', 'PossibleSolution saved - ', 1),
(256, '2020-09-15 10:13:24', 'PossibleSolution - deleted : ', 1),
(257, '2020-09-15 10:15:47', 'CollectedAccessories - deleted : ', 1),
(258, '2020-09-15 10:19:42', 'LocationNumber - deleted : ', 1),
(259, '2020-09-15 10:23:16', 'DeviceModel saved - ', 1),
(260, '2020-09-15 10:23:32', 'DeviceModel - deleted : ', 1),
(261, '2020-09-15 10:24:29', 'Role - deleted : dsd_one', 1),
(262, '2020-09-15 10:26:25', 'Role - deleted : dghyedrty5y', 1),
(263, '2020-09-15 10:33:53', 'Device Repair - saved', 1),
(264, '2020-09-15 10:37:19', 'Device Repair - saved', 1),
(265, '2020-09-15 10:44:22', 'Device Repair - saved', 1),
(266, '2020-09-15 10:45:00', 'Repair - deleted:', 1),
(267, '2020-09-15 10:45:17', 'Repair - deleted:', 1),
(268, '2020-09-15 10:55:28', 'Device Repair - saved', 1),
(269, '2020-09-15 11:21:24', 'Device Repair - saved', 1),
(270, '2020-09-15 11:21:48', 'RepairStatus saved', 1),
(271, '2020-09-15 11:25:52', 'Device Repair - saved', 1),
(272, '2020-09-15 11:29:41', 'DeviceFault saved - ', 1),
(273, '2020-09-15 11:30:14', 'Batch updated - ', 1),
(274, '2020-09-15 11:30:23', 'DeviceFault - deleted : ', 1),
(275, '2020-09-15 11:31:52', 'PossibleSolution saved - ', 1),
(276, '2020-09-15 11:32:07', 'Batch updated - ', 1),
(277, '2020-09-15 11:32:36', 'PossibleSolution - deleted : ', 1),
(278, '2020-09-15 11:33:09', 'CollectedAccessories saved - ', 1),
(279, '2020-09-15 11:33:27', 'Batch updated - ', 1),
(280, '2020-09-15 11:33:53', 'CollectedAccessories - deleted : ', 1),
(281, '2020-09-15 11:34:20', 'DeviceModel saved - ', 1),
(282, '2020-09-15 11:35:06', 'DeviceModel updated - ', 1),
(283, '2020-09-15 11:35:17', 'DeviceModel - deleted : ', 1),
(284, '2020-09-15 11:36:05', 'Batch saved - ', 1),
(285, '2020-09-15 11:36:40', 'Location Number - updated : ', 1),
(286, '2020-09-15 11:36:51', 'LocationNumber - deleted : ', 1),
(287, '2020-09-15 11:38:06', 'brand saved', 1),
(288, '2020-09-15 11:38:46', 'Brand - updated : ', 1),
(289, '2020-09-15 11:38:55', 'Role - deleted : Brand 04', 1),
(290, '2020-09-15 11:40:03', 'Device Repair - saved', 1),
(291, '2020-09-15 11:42:58', 'DeviceModel saved - ', 1),
(292, '2020-09-15 11:43:12', 'DeviceModel saved - ', 1),
(293, '2020-09-15 11:44:12', 'Device Repair - saved', 1),
(294, '2020-09-15 11:47:57', 'brand saved', 1),
(295, '2020-09-15 11:48:29', 'Device Repair - saved', 1),
(296, '2020-09-15 12:47:39', 'Logout - \'admin\'', 1),
(297, '2020-09-15 12:47:46', 'Login - \'admin\'', 1),
(298, '2020-09-15 13:27:46', 'Device Repair - saved', 1),
(299, '2020-09-15 13:29:39', 'DeviceFault saved - ', 1),
(300, '2020-09-15 13:29:53', 'PossibleSolution saved - ', 1),
(301, '2020-09-15 13:30:04', 'CollectedAccessories saved - ', 1),
(302, '2020-09-15 13:30:22', 'DeviceModel saved - ', 1),
(303, '2020-09-15 13:30:49', 'Batch saved - ', 1),
(304, '2020-09-15 13:31:06', 'brand saved', 1),
(305, '2020-09-15 13:31:49', 'RepairStatus saved', 1),
(306, '2020-09-15 13:32:39', 'Product - saved : test10', 1),
(307, '2020-09-15 13:34:20', 'Device Repair - saved', 1),
(308, '2020-09-15 13:41:08', 'DeviceFault saved - ', 1),
(309, '2020-09-15 13:41:20', 'PossibleSolution saved - ', 1),
(310, '2020-09-15 13:41:32', 'CollectedAccessories saved - ', 1),
(311, '2020-09-15 13:41:47', 'DeviceModel saved - ', 1),
(312, '2020-09-15 13:42:01', 'Batch saved - ', 1),
(313, '2020-09-15 13:42:16', 'brand saved', 1),
(314, '2020-09-15 13:42:27', 'RepairStatus saved', 1),
(315, '2020-09-15 13:42:48', 'Category saved - test11', 1),
(316, '2020-09-15 13:43:16', 'Product - saved : test11', 1),
(317, '2020-09-15 13:44:08', 'Device Repair - saved', 1),
(318, '2020-09-15 14:00:38', 'Device Repair - saved', 1),
(319, '2020-09-15 14:01:36', 'Device Repair - saved', 1),
(320, '2020-09-15 15:36:47', 'Logout - \'admin\'', 1),
(321, '2020-09-15 15:36:52', 'Login - \'admin\'', 1),
(322, '2020-09-15 16:31:00', 'Logout - \'admin\'', 1),
(323, '2020-09-15 16:34:51', 'Login - \'admin\'', 1),
(324, '2020-09-18 08:23:51', 'Login - \'admin\'', 1),
(325, '2020-09-18 09:32:40', 'Remainder - saved : ', 1),
(326, '2020-09-18 09:49:23', 'Remainder - saved : ', 1),
(327, '2020-09-18 10:05:26', 'Remainder - saved : ', 1),
(328, '2020-09-18 10:09:44', 'Remainder - deleted : ', 1),
(329, '2020-09-18 10:09:57', 'Remainder - updated : ', 1),
(330, '2020-09-18 11:25:05', 'Logout - \'admin\'', 1),
(331, '2020-09-18 11:25:09', 'Login - \'admin\'', 1),
(332, '2020-09-18 14:50:16', 'Login - \'admin\'', 1),
(333, '2020-09-18 16:28:10', 'Remainder - saved : ', 1),
(334, '2020-09-21 11:47:30', 'Login - \'admin\'', 1),
(335, '2020-09-21 15:04:18', 'Login - \'admin\'', 1),
(336, '2020-09-22 08:21:49', 'Login - \'admin\'', 1),
(337, '2020-09-22 12:55:59', 'Device Repair - saved', 1),
(338, '2020-09-22 13:01:14', 'Remainder - saved : ', 1),
(339, '2020-09-24 08:56:14', 'Login - \'admin\'', 1),
(340, '2020-09-24 09:40:32', 'JobClose - saved : ', 1),
(341, '2020-09-24 10:14:51', 'Remainder - saved : ', 1),
(342, '2020-09-24 10:43:16', 'Remainder - saved : ', 1),
(343, '2020-09-24 10:43:48', 'Remainder - saved : ', 1),
(344, '2020-09-24 10:58:40', 'Remainder - saved : ', 1),
(345, '2020-09-24 11:24:08', 'Remainder - saved : ', 1),
(346, '2020-09-24 11:25:25', 'Remainder - saved : ', 1),
(347, '2020-09-24 11:26:06', 'Remainder - saved : ', 1),
(348, '2020-09-24 11:26:17', 'Remainder - deleted : ', 1),
(349, '2020-09-24 11:26:30', 'Remainder - updated : ', 1),
(350, '2020-09-29 08:58:02', 'Login - \'admin\'', 1),
(351, '2020-09-29 09:58:27', 'GRN - saved:1', 1),
(352, '2020-09-29 09:58:27', 'Logout - \'admin\'', 1),
(353, '2020-09-29 09:58:31', 'Login - \'admin\'', 1),
(354, '2020-09-29 10:59:11', 'Allocation - saved : ', 1),
(355, '2020-09-29 11:09:01', 'Allocation - saved : ', 1),
(356, '2020-09-29 11:09:14', 'Allocation - deleted : ', 1),
(357, '2020-09-29 11:09:34', 'Allocation - updated : ', 1),
(358, '2020-09-29 11:33:35', 'Allocation - saved : ', 1),
(359, '2020-09-29 11:59:43', 'Allocation - saved : ', 1),
(360, '2020-09-29 12:53:47', 'Logout - \'admin\'', 1),
(361, '2020-09-29 12:53:50', 'Login - \'admin\'', 1),
(362, '2020-09-29 12:57:22', 'Allocation - saved : ', 1),
(363, '2020-09-29 12:57:55', 'Allocation - updated : ', 1),
(364, '2020-09-29 14:22:25', 'Allocation - saved : ', 1),
(365, '2020-09-29 14:47:48', 'GRN - saved:2', 1),
(366, '2020-09-29 15:04:02', 'Allocation - saved : ', 1),
(367, '2020-09-29 15:09:05', 'GRN - saved:3', 1),
(368, '2020-09-29 15:10:03', 'GRN - saved:4', 1),
(369, '2020-09-29 15:15:52', 'GRN - saved:5', 1),
(370, '2020-09-29 15:16:49', 'GRN - saved:6', 1),
(371, '2020-09-29 15:18:16', 'GRN - saved:7', 1),
(372, '2020-09-29 15:19:45', 'GRN - saved:8', 1),
(373, '2020-09-29 15:30:50', 'GRN - saved:11', 1),
(374, '2020-09-29 15:32:34', 'Allocation - saved : ', 1),
(375, '2020-09-29 15:33:35', 'GRN - saved:12', 1),
(376, '2020-09-29 15:34:09', 'Allocation - saved : ', 1),
(377, '2020-09-29 15:34:21', 'Allocation - saved : ', 1),
(378, '2020-09-29 15:41:20', 'GRN - saved:13', 1),
(379, '2020-09-29 15:41:40', 'Allocation - saved : ', 1),
(380, '2020-09-30 08:29:36', 'Logout - \'admin\'', 1),
(381, '2020-09-30 08:34:29', 'Login - \'admin\'', 1),
(382, '2020-09-30 08:38:51', 'GRN - saved:14', 1),
(383, '2020-09-30 08:40:33', 'GRN - saved:15', 1),
(384, '2020-09-30 08:41:55', 'GRN - saved:16', 1),
(385, '2020-09-30 08:42:14', 'Allocation - saved : ', 1),
(386, '2020-09-30 08:43:13', 'Allocation - saved : ', 1),
(387, '2020-09-30 08:45:10', 'GRN - saved:17', 1),
(388, '2020-09-30 08:55:55', 'Allocation - saved : ', 1),
(389, '2020-09-30 08:56:27', 'Allocation - saved : ', 1),
(390, '2020-09-30 08:56:51', 'Allocation - saved : ', 1),
(391, '2020-09-30 08:57:04', 'Allocation - saved : ', 1),
(392, '2020-09-30 09:00:03', 'Allocation - saved : ', 1),
(393, '2020-09-30 09:37:17', 'Logout - \'admin\'', 1),
(394, '2020-09-30 09:37:26', 'Login - \'admin\'', 1),
(395, '2020-09-30 10:57:22', 'Logout - \'admin\'', 1),
(396, '2020-09-30 10:57:44', 'Login - \'admin\'', 1),
(397, '2020-09-30 11:11:31', 'Login - \'admin\'', 1),
(398, '2020-09-30 11:22:06', 'brand saved', 1),
(399, '2020-09-30 11:22:27', 'Role - deleted : test11', 1),
(400, '2020-09-30 11:23:14', 'Brand - deleted : ', 1),
(401, '2020-09-30 11:27:09', 'Brand _ saved : ', 1),
(402, '2020-09-30 11:27:40', 'Brand _ saved : ', 1),
(403, '2020-09-30 11:29:25', 'Brand _ saved : ', 1),
(404, '2020-09-30 11:34:51', 'Discription - saved : ', 1),
(405, '2020-09-30 11:36:26', 'Discription - saved : ', 1),
(406, '2020-09-30 11:36:44', 'Discription - saved : ', 1),
(407, '2020-09-30 11:36:57', 'Discription - deleted : ', 1),
(408, '2020-09-30 11:37:12', 'Discription - updated : ', 1),
(409, '2020-09-30 15:05:17', 'Login - \'admin\'', 1),
(410, '2020-10-09 21:18:16', 'Logout - \'admin\'', 1),
(411, '2020-10-12 10:21:56', 'Login - \'admin\'', 1),
(412, '2020-10-13 15:44:17', 'Logout - \'admin\'', 1),
(413, '2020-10-13 15:44:21', 'Login - \'admin\'', 1),
(414, '2020-10-13 15:56:41', 'Device Repair - saved', 1),
(415, '2020-10-13 15:59:04', 'Device Repair - saved', 1),
(416, '2020-10-13 16:04:30', 'Product - saved : testing', 1),
(417, '2020-10-13 16:05:12', 'RepairStatus saved', 1),
(418, '2020-10-13 16:06:09', 'Brand _ saved : ', 1),
(419, '2020-10-13 16:07:03', 'Device Repair - saved', 1),
(420, '2020-10-13 16:11:08', 'Brand _ saved : ', 1),
(421, '2020-10-13 16:11:55', 'Device Repair - saved', 1),
(422, '2020-10-13 16:18:39', 'Device Repair - saved', 1),
(423, '2020-10-13 16:39:38', 'Device Repair - saved', 1),
(424, '2020-10-13 17:08:24', 'Product - saved : testing', 1),
(425, '2020-10-13 17:08:42', 'Product - updated : testing', 1),
(426, '2020-10-13 19:04:22', 'Login - \'admin\'', 1),
(427, '2020-10-14 09:27:13', 'Login - \'admin\'', 1),
(428, '2020-10-14 09:55:06', 'Location - saved : test', 1),
(429, '2020-10-14 09:55:18', 'Location - updated : test 01', 1),
(430, '2020-10-14 10:06:22', 'Product - saved : test 002', 1),
(431, '2020-10-14 10:06:48', 'Product - updated : test 002', 1),
(432, '2020-10-17 00:21:52', 'Logout - \'admin\'', 1),
(433, '2020-10-17 00:21:58', 'Login - \'admin\'', 1),
(434, '2020-10-21 22:30:20', 'Logout - \'admin\'', 1),
(435, '2020-10-21 22:30:26', 'Login - \'admin\'', 1),
(436, '2020-11-07 19:56:41', 'Login - \'admin\'', 1),
(437, '2020-11-07 20:27:59', 'Device Repair - saved', 1),
(438, '2020-11-07 22:28:32', 'Logout - \'admin\'', 1),
(439, '2020-11-07 22:28:39', 'Login - \'admin\'', 1),
(440, '2020-11-07 22:33:40', 'Product - saved : Manager', 1),
(441, '2020-11-07 22:35:24', 'Device Repair - saved', 1),
(442, '2020-11-07 22:36:00', 'Device Repair - saved', 1),
(443, '2020-11-07 22:36:47', 'Device Repair - saved', 1),
(444, '2020-11-07 23:05:12', 'Device Repair - saved', 1),
(445, '2020-11-08 12:11:28', 'Login - \'admin\'', 1),
(446, '2020-11-08 18:32:20', 'Logout - \'admin\'', 1),
(447, '2020-11-08 18:33:02', 'Login - \'admin\'', 1),
(448, '2020-11-08 18:59:07', 'Login - \'admin\'', 1),
(449, '2020-11-08 19:31:45', 'Device Repair - saved', 1),
(450, '2020-11-08 19:42:07', 'Brand _ saved : ', 1),
(451, '2020-11-08 19:44:27', 'Device Repair - saved', 1),
(452, '2020-11-08 20:23:10', 'Device Repair - saved', 1),
(453, '2020-11-08 22:05:08', 'Logout - \'admin\'', 1),
(454, '2020-11-08 22:05:20', 'Login - \'admin\'', 1),
(455, '2020-11-08 22:19:56', 'JobClose - saved : ', 1),
(456, '2020-11-09 08:39:51', 'Login - \'admin\'', 1),
(457, '2020-11-09 09:27:20', 'JobClose - saved : ', 1),
(458, '2020-11-09 09:28:49', 'JobClose - saved : ', 1),
(459, '2020-11-09 09:29:11', 'JobClose - saved : ', 1),
(460, '2020-11-09 09:29:25', 'JobClose - saved : ', 1),
(461, '2020-11-09 09:30:03', 'JobClose - saved : ', 1),
(462, '2020-11-09 09:35:40', 'JobClose - saved : ', 1),
(463, '2020-11-09 09:35:59', 'JobClose - saved : ', 1),
(464, '2020-11-09 09:37:36', 'JobClose - updated : ', 1),
(465, '2020-11-09 09:37:57', 'JobClose - updated : ', 1),
(466, '2020-11-09 10:37:04', 'Logout - \'admin\'', 1),
(467, '2020-11-09 10:37:13', 'Login - \'admin\'', 1),
(468, '2020-11-09 10:48:46', 'PaymentClose - saved : ', 1),
(469, '2020-11-09 11:31:24', 'Login - \'admin\'', 1),
(470, '2020-11-09 11:36:28', 'PaymentClose - saved : ', 1),
(471, '2020-11-09 11:36:54', 'PaymentClose - saved : ', 1),
(472, '2020-11-09 11:42:02', 'PaymentClose - saved : ', 1);

-- --------------------------------------------------------

--
-- Table structure for table `allocation`
--

CREATE TABLE `allocation` (
  `id` int(11) NOT NULL,
  `repair_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` float NOT NULL,
  `batch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE `bank` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`id`, `name`) VALUES
(1, 'Sampath Bank'),
(2, 'Commercial Bank'),
(3, 'HNB Bank'),
(4, 'NSB Bank'),
(5, 'BOC Bank'),
(6, 'Amana Bank'),
(7, 'Axis Bank'),
(8, 'Cargills Bank'),
(9, 'Citibank N.A.'),
(10, 'Deutsche Bank AG'),
(11, 'DFCC Bank'),
(12, 'Habib Bank'),
(13, 'ICICI Bank'),
(14, 'Indian Bank'),
(15, 'Indian Overseas Bank'),
(16, 'MCB Bank Ltd'),
(17, 'National Development Bank'),
(18, 'Nations Trust Bank'),
(19, 'Pan Asia Banking Corporation'),
(20, 'People\'s Bank'),
(21, 'Public Bank Berhad'),
(22, 'Seylan Bank'),
(23, 'Standard Chartered Bank'),
(24, 'State Bank of India'),
(25, 'HSBC '),
(26, 'Union Bank'),
(27, 'HDFC '),
(28, 'Lankaputhra Development Bank'),
(29, 'RDB (Regional Development)'),
(30, 'SDB (Sanasa Development)'),
(31, 'SLS (Sri Lanka Savings)'),
(32, 'SMIB (State Mortgage & Investment)');

-- --------------------------------------------------------

--
-- Table structure for table `batch`
--

CREATE TABLE `batch` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `code` varchar(45) DEFAULT NULL,
  `mfd` date DEFAULT NULL,
  `exp` date DEFAULT NULL,
  `cost` decimal(12,2) DEFAULT NULL,
  `retail_price` decimal(12,2) DEFAULT NULL,
  `wholesale_price` decimal(12,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `batch`
--

INSERT INTO `batch` (`id`, `product_id`, `code`, `mfd`, `exp`, `cost`, `retail_price`, `wholesale_price`) VALUES
(1, 2, '1', NULL, NULL, '555.00', '5552.00', '555.00');

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`id`, `name`) VALUES
(1, 'testing'),
(2, 'Nokia');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'SYSTEM TEST CATEGORY'),
(2, 'test11');

-- --------------------------------------------------------

--
-- Table structure for table `cheque`
--

CREATE TABLE `cheque` (
  `id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `amount` decimal(12,2) DEFAULT NULL,
  `cheque_no` varchar(45) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `cheque_status_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `cheque_status`
--

CREATE TABLE `cheque_status` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cheque_status`
--

INSERT INTO `cheque_status` (`id`, `name`) VALUES
(1, 'Pending'),
(2, 'Done'),
(3, 'Canceled'),
(4, 'Returned');

-- --------------------------------------------------------

--
-- Table structure for table `collected_accessories`
--

CREATE TABLE `collected_accessories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `collected_accessories`
--

INSERT INTO `collected_accessories` (`id`, `name`) VALUES
(3, 'Acc2'),
(5, 'test10'),
(6, 'test11');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `name` varchar(300) DEFAULT NULL,
  `code` varchar(45) DEFAULT NULL,
  `route_id` int(11) NOT NULL,
  `address` varchar(500) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `email` varchar(300) DEFAULT NULL,
  `balance` decimal(12,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `customer_order`
--

CREATE TABLE `customer_order` (
  `id` int(11) NOT NULL,
  `code` varchar(45) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `customer_order_status_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `customer_order_product`
--

CREATE TABLE `customer_order_product` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) DEFAULT NULL,
  `customer_order_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `customer_order_status`
--

CREATE TABLE `customer_order_status` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer_order_status`
--

INSERT INTO `customer_order_status` (`id`, `name`) VALUES
(1, 'Pending'),
(2, 'Done');

-- --------------------------------------------------------

--
-- Table structure for table `customer_payment`
--

CREATE TABLE `customer_payment` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `daily_expences`
--

CREATE TABLE `daily_expences` (
  `id` int(11) NOT NULL,
  `amount` float NOT NULL,
  `exp_date` date NOT NULL,
  `feed_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expence_cat` int(11) NOT NULL,
  `Note` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `day_start`
--

CREATE TABLE `day_start` (
  `id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `deliverer`
--

CREATE TABLE `deliverer` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `number` varchar(45) DEFAULT NULL,
  `route_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `deliverer`
--

INSERT INTO `deliverer` (`id`, `name`, `number`, `route_id`) VALUES
(1, 'TEST LOCATON', 'TEST LOCATION ADDRESS', 1);

-- --------------------------------------------------------

--
-- Table structure for table `deliverer_inventory`
--

CREATE TABLE `deliverer_inventory` (
  `id` int(11) NOT NULL,
  `inventory_id` int(11) NOT NULL,
  `qty` int(11) DEFAULT NULL,
  `deliverer_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `deliverer_user`
--

CREATE TABLE `deliverer_user` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `deliverer_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `designation`
--

CREATE TABLE `designation` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `designation`
--

INSERT INTO `designation` (`id`, `name`) VALUES
(1, 'Manager');

-- --------------------------------------------------------

--
-- Table structure for table `device_fault`
--

CREATE TABLE `device_fault` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `device_fault`
--

INSERT INTO `device_fault` (`id`, `name`) VALUES
(1, 'rqerq'),
(2, 'fault one'),
(3, 'fault twos'),
(4, 'qqq'),
(5, 'test10'),
(6, 'test11');

-- --------------------------------------------------------

--
-- Table structure for table `device_model`
--

CREATE TABLE `device_model` (
  `id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `device_model`
--

INSERT INTO `device_model` (`id`, `name`) VALUES
(1, 'test 01'),
(2, 'test 02'),
(3, 'test10'),
(4, 'test11');

-- --------------------------------------------------------

--
-- Table structure for table `device_repair`
--

CREATE TABLE `device_repair` (
  `id` int(11) NOT NULL,
  `job_no` int(11) NOT NULL,
  `job_date` date NOT NULL,
  `system_date` datetime NOT NULL,
  `customer_name` varchar(500) NOT NULL,
  `customer_address` varchar(500) NOT NULL,
  `id_number` varchar(100) NOT NULL,
  `contact_no` varchar(100) NOT NULL,
  `delivery_date` datetime NOT NULL,
  `product` int(11) NOT NULL,
  `device_model_id` int(11) NOT NULL,
  `imei_serial` varchar(500) NOT NULL,
  `location_number` int(200) NOT NULL,
  `job_cost` float NOT NULL,
  `advanced_payment` float NOT NULL,
  `brand_id` int(11) NOT NULL,
  `repair_status` int(11) NOT NULL,
  `comment` mediumtext NOT NULL,
  `image_top` varchar(1000) NOT NULL,
  `image_bottom` varchar(1000) NOT NULL,
  `image_right` varchar(1000) NOT NULL,
  `image_left` varchar(1000) NOT NULL,
  `image_front` varchar(1000) NOT NULL,
  `image_back` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `device_repair`
--

INSERT INTO `device_repair` (`id`, `job_no`, `job_date`, `system_date`, `customer_name`, `customer_address`, `id_number`, `contact_no`, `delivery_date`, `product`, `device_model_id`, `imei_serial`, `location_number`, `job_cost`, `advanced_payment`, `brand_id`, `repair_status`, `comment`, `image_top`, `image_bottom`, `image_right`, `image_left`, `image_front`, `image_back`) VALUES
(2, 2, '2020-11-07', '2020-11-07 22:35:23', 'Dileep Prabath', '40/B Green View', '111', '111111', '2020-11-07 00:00:00', 1, 2, '333333333333333333', 3, 222, 4, 1, 5, 'eedsfewftg', '', '', '', '', '', ''),
(3, 2, '2020-11-07', '2020-11-07 22:36:00', 'Dileep Prabath', '40/B Green View', '111', '111111', '2020-11-07 00:00:00', 1, 2, '333333333333333333', 3, 222, 4, 1, 5, 'eedsfewftg', '', '', '', '', '', ''),
(4, 4, '2020-11-07', '2020-11-07 22:36:47', 'Dileep Prabath', '40/B Green View', '111', '111111', '2020-11-07 00:00:00', 1, 3, '22222', 3, 45, 54, 1, 5, 'erewtw', '', '', '', '', '', ''),
(5, 5, '2020-11-07', '2020-11-07 23:05:11', 'Dileep Prabath', '40/B Green View', '9999', '5', '2020-11-07 00:00:00', 1, 2, '99999', 3, 4, 5555, 1, 5, 'hyjftyujyuy', '', '', '', '', '', ''),
(6, 8, '2020-11-08', '2020-11-08 19:31:44', 'Dileep Prabath', '40/B Green View', '6586', '6868', '2020-11-17 00:00:00', 1, 3, '45', 6, 86, 868, 1, 5, '686868', '', '', '', '', '', ''),
(7, 7, '2020-11-08', '2020-11-08 19:44:26', 'Dileep Prabath', '40/B Green View', '111', '111111', '2020-11-22 00:00:00', 1, 4, '99999', 3, 0, 0, 2, 5, 'hgfdhtgh', '', '', '', '', '', ''),
(8, 10, '2020-11-09', '2020-11-08 20:23:10', 'Dileep Prabath', '40/B Green View', '111', '111111', '0000-00-00 00:00:00', 1, 2, '22222', 6, 45, 11111, 2, 5, 'uiguihyui', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `discription`
--

CREATE TABLE `discription` (
  `id` int(11) NOT NULL,
  `discription` varchar(1000) NOT NULL,
  `price_discription` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `discription`
--

INSERT INTO `discription` (`id`, `discription`, `price_discription`) VALUES
(1, 'werfgwerg', 'rgrewg'),
(2, 'rhrthfgjhtgjm tkuyt', 'tgh tr nb09fbiknfgkhlgf,kn');

-- --------------------------------------------------------

--
-- Table structure for table `expence_cat`
--

CREATE TABLE `expence_cat` (
  `id` int(11) NOT NULL,
  `cat_name` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `grn`
--

CREATE TABLE `grn` (
  `id` int(11) NOT NULL,
  `code` varchar(45) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  `purchase_order_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `grn_type_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `grn`
--

INSERT INTO `grn` (`id`, `code`, `date_time`, `purchase_order_id`, `user_id`, `grn_type_id`, `supplier_id`) VALUES
(1, '1', '2020-09-29 09:25:07', NULL, 1, 1, 7),
(2, '2', '2020-09-29 14:47:26', NULL, 1, 1, 7),
(3, '3', '2020-09-29 15:08:16', NULL, 1, 1, 7),
(4, '4', '2020-09-29 15:09:38', NULL, 1, 1, 7),
(5, '5', '2020-09-29 15:15:36', NULL, 1, 1, 7),
(6, '6', '2020-09-29 15:16:38', NULL, 1, 1, 7),
(7, '7', '2020-09-29 15:17:57', NULL, 1, 1, 7),
(8, '8', '2020-09-29 15:19:30', NULL, 1, 1, 7),
(11, '11', '2020-09-29 15:30:37', NULL, 1, 1, 7),
(12, '12', '2020-09-29 15:33:17', NULL, 1, 1, 7),
(13, '13', '2020-09-29 15:41:05', NULL, 1, 1, 7),
(14, '14', '2020-09-30 08:38:35', NULL, 1, 1, 7),
(15, '15', '2020-09-30 08:40:20', NULL, 1, 1, 7),
(16, '16', '2020-09-30 08:41:27', NULL, 1, 1, 7),
(17, '17', '2020-09-30 08:44:49', NULL, 1, 1, 7);

-- --------------------------------------------------------

--
-- Table structure for table `grn_material`
--

CREATE TABLE `grn_material` (
  `id` int(11) NOT NULL,
  `grn_id` int(11) NOT NULL,
  `material_id` int(11) NOT NULL,
  `volume` decimal(10,3) DEFAULT NULL,
  `unit_price` decimal(12,2) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `grn_product`
--

CREATE TABLE `grn_product` (
  `id` int(11) NOT NULL,
  `grn_id` int(11) NOT NULL,
  `qty` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `grn_product`
--

INSERT INTO `grn_product` (`id`, `grn_id`, `qty`, `user_id`, `batch_id`) VALUES
(1, 1, 1, 1, 1),
(2, 2, 1, 1, 1),
(3, 3, 1, 1, 1),
(4, 4, 2, 1, 1),
(5, 5, 1, 1, 1),
(6, 6, 1, 1, 1),
(7, 7, 1, 1, 1),
(8, 8, 1, 1, 1),
(11, 11, 1, 1, 1),
(12, 12, 2, 1, 1),
(13, 13, 1, 1, 1),
(14, 14, 1, 1, 1),
(15, 15, 1, 1, 1),
(16, 16, 3, 1, 1),
(17, 17, 6, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `grn_type`
--

CREATE TABLE `grn_type` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `grn_type`
--

INSERT INTO `grn_type` (`id`, `name`) VALUES
(1, 'Product'),
(2, 'Material');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL,
  `qty` int(11) DEFAULT NULL,
  `batch_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`id`, `qty`, `batch_id`, `product_id`) VALUES
(4, 0, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `id` int(11) NOT NULL,
  `code` varchar(45) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  `reurn_invoice_id` int(11) DEFAULT NULL,
  `invoice_status_id` int(11) NOT NULL,
  `gross_amount` decimal(12,2) DEFAULT NULL,
  `net_amount` decimal(12,2) DEFAULT NULL,
  `balance` decimal(12,2) DEFAULT NULL,
  `customer_order_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `invoice_type_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `invoice_condition_id` int(11) NOT NULL,
  `deliverer_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `invoice_condition`
--

CREATE TABLE `invoice_condition` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `invoice_condition`
--

INSERT INTO `invoice_condition` (`id`, `name`) VALUES
(1, 'New'),
(2, 'Return');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_inventory`
--

CREATE TABLE `invoice_inventory` (
  `id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `inventory_id` int(11) NOT NULL,
  `qty` int(11) DEFAULT NULL,
  `price` decimal(12,2) DEFAULT NULL,
  `unit_discount` decimal(12,2) DEFAULT NULL,
  `gross_amount` decimal(12,2) DEFAULT NULL,
  `net_amount` decimal(12,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `invoice_return`
--

CREATE TABLE `invoice_return` (
  `id` int(11) NOT NULL,
  `date_time` datetime DEFAULT NULL,
  `invoice_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `note` text,
  `deliverer_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `invoice_return_inventory`
--

CREATE TABLE `invoice_return_inventory` (
  `id` int(11) NOT NULL,
  `invoice_return_id` int(11) NOT NULL,
  `inventory_id` int(11) NOT NULL,
  `qty` int(11) DEFAULT NULL,
  `return_reason_id` int(11) NOT NULL,
  `unit_price` decimal(12,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `invoice_status`
--

CREATE TABLE `invoice_status` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `invoice_status`
--

INSERT INTO `invoice_status` (`id`, `name`) VALUES
(1, 'Pending'),
(2, 'Done');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_type`
--

CREATE TABLE `invoice_type` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `invoice_type`
--

INSERT INTO `invoice_type` (`id`, `name`) VALUES
(1, 'Normal'),
(2, 'Retail');

-- --------------------------------------------------------

--
-- Table structure for table `job_close`
--

CREATE TABLE `job_close` (
  `id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `repair_id` int(11) NOT NULL,
  `comment` varchar(10000) NOT NULL,
  `customer` varchar(500) NOT NULL,
  `amount` int(11) NOT NULL,
  `type` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `job_close`
--

INSERT INTO `job_close` (`id`, `status`, `repair_id`, `comment`, `customer`, `amount`, `type`) VALUES
(1, 5, 3, 'gfsdg', 'fgfdg', 5555, ''),
(2, 3, 3, 'hedrth', '', -100, ''),
(3, 3, 3, 'sfsf', '', -1100, ''),
(4, 3, 3, 'sfsf', '', -1100, ''),
(5, 3, 3, 'sfsf', '', -1100, ''),
(6, 3, 2, 'fsdfef', '', -11, ''),
(7, 3, 3, 'ghfjgf', '', 3000, ''),
(8, 4, 8, 'fdfgd', '', 1000, '');

-- --------------------------------------------------------

--
-- Table structure for table `job_close_status`
--

CREATE TABLE `job_close_status` (
  `id` int(11) NOT NULL,
  `name` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `job_close_status`
--

INSERT INTO `job_close_status` (`id`, `name`) VALUES
(3, 'kurunegala'),
(4, 'adfasfdfafefewdfgewfg svfsdg'),
(5, 'popop'),
(8, '111'),
(9, 'sedfgwsetgw'),
(10, 'gfdhgdb11111111111111');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`id`, `name`) VALUES
(1, 'test 01');

-- --------------------------------------------------------

--
-- Table structure for table `location_number`
--

CREATE TABLE `location_number` (
  `id` int(30) NOT NULL,
  `name` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `location_number`
--

INSERT INTO `location_number` (`id`, `name`) VALUES
(2, 'ffds'),
(3, 'Location One'),
(4, 'Test'),
(6, 'test10'),
(7, 'test11');

-- --------------------------------------------------------

--
-- Table structure for table `material`
--

CREATE TABLE `material` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `material_stock`
--

CREATE TABLE `material_stock` (
  `id` int(11) NOT NULL,
  `material_id` int(11) NOT NULL,
  `volume` decimal(10,3) DEFAULT NULL,
  `grn_material_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

CREATE TABLE `module` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `module`
--

INSERT INTO `module` (`id`, `name`) VALUES
(1, 'User'),
(2, 'Privilege'),
(3, 'Designation'),
(4, 'Target'),
(5, 'Category'),
(6, 'Product'),
(7, 'Batch'),
(8, 'Material'),
(9, 'ProductionPlan'),
(10, 'Production'),
(11, 'Supplier'),
(12, 'Customer'),
(13, 'Route'),
(14, 'ProductPO'),
(15, 'MaterialPO'),
(16, 'ProductGRN'),
(17, 'MaterialGRN'),
(18, 'Invoice'),
(19, 'Payment'),
(20, 'Return'),
(21, 'Deliverer'),
(22, 'DelivererInventory'),
(23, 'MaterialStock'),
(24, 'Inventory'),
(25, 'Cheque'),
(26, 'Role');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `code` varchar(45) DEFAULT NULL,
  `payment_method_id` int(11) NOT NULL,
  `payment_status_id` int(11) NOT NULL,
  `date_time` datetime DEFAULT NULL,
  `amount` decimal(12,2) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `payment_type_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `payment_cheque`
--

CREATE TABLE `payment_cheque` (
  `id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `cheque_id` int(11) NOT NULL,
  `amount` decimal(12,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `payment_close`
--

CREATE TABLE `payment_close` (
  `id` int(11) NOT NULL,
  `repair_id` int(11) NOT NULL,
  `system_date` datetime NOT NULL,
  `comment` varchar(1000) NOT NULL,
  `value` int(11) NOT NULL,
  `type` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_close`
--

INSERT INTO `payment_close` (`id`, `repair_id`, `system_date`, `comment`, `value`, `type`) VALUES
(1, 3, '2020-11-09 10:48:45', 'xxssc', 0, ''),
(2, 3, '2020-11-09 11:36:28', 'rtgrgt', -4324534, ''),
(3, 5, '2020-11-09 11:36:54', 'drfgde', 54564, ''),
(4, 8, '2020-11-09 11:42:02', 'sdfs', 222, '');

-- --------------------------------------------------------

--
-- Table structure for table `payment_invoice`
--

CREATE TABLE `payment_invoice` (
  `id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `amount` decimal(12,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `payment_method`
--

CREATE TABLE `payment_method` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payment_method`
--

INSERT INTO `payment_method` (`id`, `name`) VALUES
(1, 'Cash'),
(2, 'Cheque'),
(3, 'Credit Note');

-- --------------------------------------------------------

--
-- Table structure for table `payment_status`
--

CREATE TABLE `payment_status` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payment_status`
--

INSERT INTO `payment_status` (`id`, `name`) VALUES
(1, 'Pending'),
(2, 'Done'),
(3, 'Canceled');

-- --------------------------------------------------------

--
-- Table structure for table `payment_type`
--

CREATE TABLE `payment_type` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payment_type`
--

INSERT INTO `payment_type` (`id`, `name`) VALUES
(1, 'Invoice Payment'),
(2, 'Customer Payment');

-- --------------------------------------------------------

--
-- Table structure for table `petty_cash`
--

CREATE TABLE `petty_cash` (
  `id` int(11) NOT NULL,
  `reson` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `petty_date` datetime NOT NULL,
  `amount` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `possible_solution`
--

CREATE TABLE `possible_solution` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `possible_solution`
--

INSERT INTO `possible_solution` (`id`, `name`) VALUES
(2, 'Solution 01'),
(4, 'test10'),
(5, 'test11');

-- --------------------------------------------------------

--
-- Table structure for table `privilege`
--

CREATE TABLE `privilege` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `view` tinyint(1) DEFAULT NULL,
  `ins` tinyint(1) DEFAULT NULL,
  `upd` tinyint(1) DEFAULT NULL,
  `del` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `privilege`
--

INSERT INTO `privilege` (`id`, `role_id`, `module_id`, `view`, `ins`, `upd`, `del`) VALUES
(1, 1, 2, 1, 1, 1, 1),
(2, 1, 1, 1, 1, 1, 1),
(3, 1, 3, 1, 1, 1, 1),
(4, 1, 4, 1, 1, 1, 1),
(5, 1, 5, 1, 1, 1, 1),
(6, 1, 6, 1, 1, 1, 1),
(7, 1, 7, 1, 1, 1, 1),
(8, 1, 8, 1, 1, 1, 1),
(9, 1, 9, 1, 1, 1, 1),
(10, 1, 10, 1, 1, 1, 1),
(11, 1, 11, 1, 1, 1, 1),
(12, 1, 12, 1, 1, 1, 1),
(13, 1, 13, 1, 1, 1, 1),
(14, 1, 14, 1, 1, 1, 1),
(15, 1, 15, 1, 1, 1, 1),
(16, 1, 16, 1, 1, 1, 1),
(17, 1, 17, 1, 1, 1, 1),
(18, 1, 18, 1, 1, 1, 1),
(19, 1, 19, 1, 1, 1, 1),
(20, 1, 20, 1, 1, 1, 1),
(21, 1, 21, 1, 1, 1, 1),
(22, 1, 22, 1, 1, 1, 1),
(23, 1, 23, 1, 1, 1, 1),
(24, 1, 24, 1, 1, 1, 1),
(25, 1, 25, 1, 1, 1, 1),
(26, 1, 26, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `roq` int(11) DEFAULT NULL,
  `max_qty` int(11) DEFAULT NULL,
  `min_qty` int(11) DEFAULT NULL,
  `code` varchar(100) NOT NULL,
  `barcode` varchar(500) DEFAULT NULL,
  `warrenty_period` float NOT NULL DEFAULT '0',
  `image` varchar(200) DEFAULT NULL,
  `location_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `category_id`, `roq`, `max_qty`, `min_qty`, `code`, `barcode`, `warrenty_period`, `image`, `location_id`) VALUES
(1, 'Manager', 2, 1, 1, 1, 'ITM-00001', '1', 1, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `production`
--

CREATE TABLE `production` (
  `id` int(11) NOT NULL,
  `code` varchar(45) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `description` text,
  `production_status_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `production_material`
--

CREATE TABLE `production_material` (
  `id` int(11) NOT NULL,
  `production_id` int(11) NOT NULL,
  `material_id` int(11) NOT NULL,
  `volume` decimal(10,3) DEFAULT NULL,
  `wastage` decimal(10,3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `production_material_stock`
--

CREATE TABLE `production_material_stock` (
  `id` int(11) NOT NULL,
  `production_id` int(11) NOT NULL,
  `material_stock_id` int(11) NOT NULL,
  `volume` decimal(10,3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `production_product`
--

CREATE TABLE `production_product` (
  `id` int(11) NOT NULL,
  `production_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `qty` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `production_status`
--

CREATE TABLE `production_status` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `production_status`
--

INSERT INTO `production_status` (`id`, `name`) VALUES
(1, 'Pending'),
(2, 'Done'),
(3, 'Canceled');

-- --------------------------------------------------------

--
-- Table structure for table `product_return`
--

CREATE TABLE `product_return` (
  `id` int(11) NOT NULL,
  `date_time` varchar(45) DEFAULT NULL,
  `note` text,
  `user_id` int(11) NOT NULL,
  `deliverer_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `product_return_batch`
--

CREATE TABLE `product_return_batch` (
  `id` int(11) NOT NULL,
  `product_return_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `return_reason_id` int(11) NOT NULL,
  `qty` int(11) DEFAULT NULL,
  `unit_price` decimal(12,2) DEFAULT NULL,
  `discount` float DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `product_return_invoice`
--

CREATE TABLE `product_return_invoice` (
  `id` int(11) NOT NULL,
  `product_return_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `return_amount` float NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order`
--

CREATE TABLE `purchase_order` (
  `id` int(11) NOT NULL,
  `code` varchar(45) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `supplier_id` int(11) NOT NULL,
  `purchase_order_type_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `purchase_order_status_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order_material`
--

CREATE TABLE `purchase_order_material` (
  `id` int(11) NOT NULL,
  `purchase_order_id` int(11) NOT NULL,
  `material_id` int(11) NOT NULL,
  `volume` decimal(10,3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order_product`
--

CREATE TABLE `purchase_order_product` (
  `id` int(11) NOT NULL,
  `purchase_order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order_status`
--

CREATE TABLE `purchase_order_status` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `purchase_order_status`
--

INSERT INTO `purchase_order_status` (`id`, `name`) VALUES
(1, 'Pending'),
(2, 'Done');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order_type`
--

CREATE TABLE `purchase_order_type` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `purchase_order_type`
--

INSERT INTO `purchase_order_type` (`id`, `name`) VALUES
(1, 'Product'),
(2, 'Material');

-- --------------------------------------------------------

--
-- Table structure for table `remainder`
--

CREATE TABLE `remainder` (
  `id` int(100) NOT NULL,
  `delivery_date` date NOT NULL,
  `comment` varchar(1000) NOT NULL,
  `repair_id` int(11) NOT NULL,
  `repair_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `repaire_device_fault`
--

CREATE TABLE `repaire_device_fault` (
  `id` int(11) NOT NULL,
  `repair_id` int(11) NOT NULL,
  `device_fault_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `repaire_device_fault`
--

INSERT INTO `repaire_device_fault` (`id`, `repair_id`, `device_fault_id`) VALUES
(1, 31, 2),
(2, 32, 2),
(3, 33, 2),
(4, 34, 3),
(5, 35, 2),
(6, 36, 2),
(7, 37, 2),
(8, 40, 3),
(9, 42, 2),
(10, 43, 2),
(11, 44, 2),
(12, 44, 3),
(13, 45, 2),
(14, 46, 2),
(15, 47, 2),
(16, 47, 3),
(17, 47, 4),
(18, 48, 2),
(19, 48, 3),
(20, 48, 4),
(21, 49, 2),
(22, 49, 3),
(23, 49, 4),
(24, 50, 3),
(25, 50, 4),
(26, 52, 2),
(27, 52, 3),
(28, 52, 4),
(29, 53, 2),
(30, 53, 3),
(31, 53, 4),
(32, 54, 2),
(33, 54, 3),
(34, 55, 4),
(35, 56, 4),
(36, 57, 4),
(37, 57, 6),
(38, 58, 4),
(39, 59, 3),
(40, 60, 3),
(41, 60, 4),
(42, 60, 6),
(43, 61, 6),
(44, 63, 6),
(45, 64, 8),
(46, 65, 9),
(47, 66, 6),
(48, 67, 5),
(49, 68, 5),
(50, 71, 2),
(51, 73, 2),
(52, 73, 3),
(53, 75, 1),
(54, 75, 2),
(55, 2, 2),
(56, 3, 2),
(57, 4, 3),
(58, 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `repair_collected_accessories`
--

CREATE TABLE `repair_collected_accessories` (
  `id` int(11) NOT NULL,
  `collected_accessories` int(11) NOT NULL,
  `repair_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `repair_collected_accessories`
--

INSERT INTO `repair_collected_accessories` (`id`, `collected_accessories`, `repair_id`) VALUES
(1, 2, 31),
(2, 2, 32),
(3, 2, 33),
(4, 3, 34),
(5, 2, 35),
(6, 2, 36),
(7, 2, 37),
(8, 3, 40),
(9, 2, 41),
(10, 2, 49),
(11, 3, 49),
(12, 2, 50),
(13, 3, 50),
(14, 2, 52),
(15, 3, 52),
(16, 2, 53),
(17, 3, 53),
(18, 3, 54),
(19, 3, 55),
(20, 3, 56),
(21, 3, 57),
(22, 3, 58),
(23, 3, 59),
(24, 3, 60),
(25, 3, 61),
(26, 5, 64),
(27, 6, 65),
(28, 6, 66),
(29, 5, 67),
(30, 6, 68),
(31, 3, 73),
(32, 5, 73),
(33, 3, 75),
(34, 3, 2),
(35, 3, 3),
(36, 3, 4),
(37, 3, 5);

-- --------------------------------------------------------

--
-- Table structure for table `repair_possible_solution`
--

CREATE TABLE `repair_possible_solution` (
  `id` int(11) NOT NULL,
  `possible_solution_id` int(11) NOT NULL,
  `repair_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `repair_possible_solution`
--

INSERT INTO `repair_possible_solution` (`id`, `possible_solution_id`, `repair_id`) VALUES
(1, 2, 31),
(2, 2, 32),
(3, 2, 33),
(4, 2, 35),
(5, 2, 36),
(6, 2, 37),
(7, 2, 41),
(8, 2, 42),
(9, 2, 43),
(10, 2, 44),
(11, 2, 45),
(12, 2, 46),
(13, 2, 47),
(14, 2, 48),
(15, 2, 49),
(16, 2, 50),
(17, 2, 51),
(18, 2, 52),
(19, 2, 53),
(20, 2, 54),
(21, 2, 55),
(22, 2, 56),
(23, 2, 57),
(24, 2, 58),
(25, 2, 59),
(26, 2, 60),
(27, 4, 64),
(28, 5, 65),
(29, 5, 66),
(30, 4, 67),
(31, 4, 68),
(32, 5, 68),
(33, 2, 73),
(34, 4, 73),
(35, 2, 75),
(36, 4, 75),
(37, 2, 2),
(38, 2, 3),
(39, 2, 4),
(40, 2, 5);

-- --------------------------------------------------------

--
-- Table structure for table `repair_status`
--

CREATE TABLE `repair_status` (
  `id` int(100) NOT NULL,
  `name` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `repair_status`
--

INSERT INTO `repair_status` (`id`, `name`) VALUES
(5, 'testing');

-- --------------------------------------------------------

--
-- Table structure for table `return_reason`
--

CREATE TABLE `return_reason` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `return_reason`
--

INSERT INTO `return_reason` (`id`, `name`) VALUES
(1, 'Customer Return'),
(2, 'Re Stock'),
(3, 'Damage'),
(4, 'Expire');

-- --------------------------------------------------------

--
-- Table structure for table `return_table`
--

CREATE TABLE `return_table` (
  `id` int(11) NOT NULL,
  `date_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `note` varchar(500) NOT NULL,
  `user_id` int(11) NOT NULL,
  `deliverer_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `name`) VALUES
(1, 'SUPER ADMIN');

-- --------------------------------------------------------

--
-- Table structure for table `route`
--

CREATE TABLE `route` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `route`
--

INSERT INTO `route` (`id`, `name`) VALUES
(1, 'General');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `id` int(11) NOT NULL,
  `name` varchar(300) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `email` varchar(300) DEFAULT NULL,
  `contact_no` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`id`, `name`, `address`, `email`, `contact_no`) VALUES
(7, 'INITIAL', 'INITIAL', '', '0774343183');

-- --------------------------------------------------------

--
-- Table structure for table `target`
--

CREATE TABLE `target` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `target_month_id` int(11) NOT NULL,
  `amount` varchar(45) DEFAULT NULL,
  `year` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `target_month`
--

CREATE TABLE `target_month` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `designation_id` int(11) NOT NULL,
  `user_status_id` int(11) NOT NULL,
  `name` varchar(400) DEFAULT NULL,
  `username` varchar(200) DEFAULT NULL,
  `password` text,
  `dob` date DEFAULT NULL,
  `contact_no` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `nic` varchar(400) DEFAULT NULL,
  `address` varchar(400) DEFAULT NULL,
  `image` varchar(400) DEFAULT NULL,
  `soft_delete` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `designation_id`, `user_status_id`, `name`, `username`, `password`, `dob`, `contact_no`, `email`, `nic`, `address`, `image`, `soft_delete`) VALUES
(1, 1, 1, 'Admin', 'admin', '$2y$10$ZDUyNDYzYjYzM2VjZTNmMOkH2c0VKNI5.N43XGEQCXPHwSqInqNTW', '1995-05-05', '0336665552', 'aaa@bbb.com', '65465465v', '313/1 skjhsdkjcnbdkjcbnkdjnc', '5e6baafcc0cf0.png', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`id`, `role_id`, `user_id`) VALUES
(23, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_status`
--

CREATE TABLE `user_status` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_status`
--

INSERT INTO `user_status` (`id`, `name`) VALUES
(1, 'Active'),
(2, 'Deactive');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity`
--
ALTER TABLE `activity`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_activity_user1_idx` (`user_id`);

--
-- Indexes for table `allocation`
--
ALTER TABLE `allocation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `repair_id` (`repair_id`),
  ADD KEY `batch_id` (`batch_id`);

--
-- Indexes for table `bank`
--
ALTER TABLE `bank`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `batch`
--
ALTER TABLE `batch`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_batch_product1_idx` (`product_id`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cheque`
--
ALTER TABLE `cheque`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_cheque_cheque_status1_idx` (`cheque_status_id`),
  ADD KEY `fk_cheque_bank1_idx` (`bank_id`);

--
-- Indexes for table `cheque_status`
--
ALTER TABLE `cheque_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `collected_accessories`
--
ALTER TABLE `collected_accessories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_customer_route1_idx` (`route_id`);

--
-- Indexes for table `customer_order`
--
ALTER TABLE `customer_order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_order_customer1_idx` (`customer_id`),
  ADD KEY `fk_order_user1_idx` (`user_id`),
  ADD KEY `fk_customer_order_customer_order_status1_idx` (`customer_order_status_id`);

--
-- Indexes for table `customer_order_product`
--
ALTER TABLE `customer_order_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_order_has_product_product1_idx` (`product_id`),
  ADD KEY `fk_order_product_customer_order1_idx` (`customer_order_id`);

--
-- Indexes for table `customer_order_status`
--
ALTER TABLE `customer_order_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_payment`
--
ALTER TABLE `customer_payment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_customer_has_payment_payment1_idx` (`payment_id`),
  ADD KEY `fk_customer_has_payment_customer1_idx` (`customer_id`);

--
-- Indexes for table `daily_expences`
--
ALTER TABLE `daily_expences`
  ADD PRIMARY KEY (`id`),
  ADD KEY `expence_cat` (`expence_cat`);

--
-- Indexes for table `day_start`
--
ALTER TABLE `day_start`
  ADD PRIMARY KEY (`id`),
  ADD KEY `location_id` (`location_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `deliverer`
--
ALTER TABLE `deliverer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_distributer_route1_idx` (`route_id`);

--
-- Indexes for table `deliverer_inventory`
--
ALTER TABLE `deliverer_inventory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_distributer_has_inventory_inventory1_idx` (`inventory_id`),
  ADD KEY `fk_deliverer_inventory_deliverer1_idx` (`deliverer_id`);

--
-- Indexes for table `deliverer_user`
--
ALTER TABLE `deliverer_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_distributer_has_user_user1_idx` (`user_id`),
  ADD KEY `fk_deliverer_user_deliverer1_idx` (`deliverer_id`);

--
-- Indexes for table `designation`
--
ALTER TABLE `designation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `device_fault`
--
ALTER TABLE `device_fault`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `device_model`
--
ALTER TABLE `device_model`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `device_repair`
--
ALTER TABLE `device_repair`
  ADD PRIMARY KEY (`id`),
  ADD KEY `device_model_id` (`device_model_id`),
  ADD KEY `brand_id` (`brand_id`),
  ADD KEY `repair_status` (`repair_status`),
  ADD KEY `product` (`product`),
  ADD KEY `location_number` (`location_number`);

--
-- Indexes for table `discription`
--
ALTER TABLE `discription`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expence_cat`
--
ALTER TABLE `expence_cat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `grn`
--
ALTER TABLE `grn`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_grn_purchase_order1_idx` (`purchase_order_id`),
  ADD KEY `fk_grn_user1_idx` (`user_id`),
  ADD KEY `fk_grn_grn_type1_idx` (`grn_type_id`),
  ADD KEY `fk_grn_supplier1_idx` (`supplier_id`);

--
-- Indexes for table `grn_material`
--
ALTER TABLE `grn_material`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_grn_has_material_material1_idx` (`material_id`),
  ADD KEY `fk_grn_has_material_grn1_idx` (`grn_id`),
  ADD KEY `fk_grn_material_user1_idx` (`user_id`);

--
-- Indexes for table `grn_product`
--
ALTER TABLE `grn_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_grn_has_product_grn1_idx` (`grn_id`),
  ADD KEY `fk_grn_product_batch1_idx` (`batch_id`),
  ADD KEY `fk_grn_product_user1_idx` (`user_id`);

--
-- Indexes for table `grn_type`
--
ALTER TABLE `grn_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_inventory_batch1_idx` (`batch_id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_invoice_customer1_idx` (`customer_id`),
  ADD KEY `fk_invoice_invoice1_idx` (`reurn_invoice_id`),
  ADD KEY `fk_invoice_invoice_status1_idx` (`invoice_status_id`),
  ADD KEY `fk_invoice_customer_order1_idx` (`customer_order_id`),
  ADD KEY `fk_invoice_invoice_type1_idx` (`invoice_type_id`),
  ADD KEY `fk_invoice_user1_idx` (`user_id`),
  ADD KEY `fk_invoice_invoice_condition1_idx` (`invoice_condition_id`),
  ADD KEY `fk_invoice_deliverer1_idx` (`deliverer_id`);

--
-- Indexes for table `invoice_condition`
--
ALTER TABLE `invoice_condition`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoice_inventory`
--
ALTER TABLE `invoice_inventory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_invoice_product_invoice1_idx` (`invoice_id`),
  ADD KEY `fk_invoice_product_inventory1_idx` (`inventory_id`);

--
-- Indexes for table `invoice_return`
--
ALTER TABLE `invoice_return`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_return_invoice1_idx` (`invoice_id`),
  ADD KEY `fk_return_user1_idx` (`user_id`),
  ADD KEY `fk_invoice_return_deliverer1_idx` (`deliverer_id`);

--
-- Indexes for table `invoice_return_inventory`
--
ALTER TABLE `invoice_return_inventory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_return_has_inventory_inventory1_idx` (`inventory_id`),
  ADD KEY `fk_product_return_inventory_invoice_return1_idx` (`invoice_return_id`),
  ADD KEY `fk_invoice_return_inventory_return_reason1_idx` (`return_reason_id`);

--
-- Indexes for table `invoice_status`
--
ALTER TABLE `invoice_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoice_type`
--
ALTER TABLE `invoice_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_close`
--
ALTER TABLE `job_close`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`status`),
  ADD KEY `repair_id` (`repair_id`);

--
-- Indexes for table `job_close_status`
--
ALTER TABLE `job_close_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `location_number`
--
ALTER TABLE `location_number`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `material`
--
ALTER TABLE `material`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `material_stock`
--
ALTER TABLE `material_stock`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_material_stock_material1_idx` (`material_id`),
  ADD KEY `fk_material_stock_grn_material1_idx` (`grn_material_id`);

--
-- Indexes for table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_invoice_payment_payment_method1_idx` (`payment_method_id`),
  ADD KEY `fk_invoice_payment_user1_idx` (`user_id`),
  ADD KEY `fk_payment_payment_status1_idx` (`payment_status_id`),
  ADD KEY `fk_payment_payment_type1_idx` (`payment_type_id`);

--
-- Indexes for table `payment_cheque`
--
ALTER TABLE `payment_cheque`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_invoice_payment_has_cheque_cheque1_idx` (`cheque_id`),
  ADD KEY `fk_invoice_payment_has_cheque_invoice_payment1_idx` (`payment_id`);

--
-- Indexes for table `payment_close`
--
ALTER TABLE `payment_close`
  ADD PRIMARY KEY (`id`),
  ADD KEY `repair_id` (`repair_id`);

--
-- Indexes for table `payment_invoice`
--
ALTER TABLE `payment_invoice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_payment_invoice_payment1_idx` (`payment_id`),
  ADD KEY `fk_payment_invoice_invoice1_idx` (`invoice_id`);

--
-- Indexes for table `payment_method`
--
ALTER TABLE `payment_method`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_status`
--
ALTER TABLE `payment_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_type`
--
ALTER TABLE `payment_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `petty_cash`
--
ALTER TABLE `petty_cash`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `possible_solution`
--
ALTER TABLE `possible_solution`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `privilege`
--
ALTER TABLE `privilege`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_role_has_module_module1_idx` (`module_id`),
  ADD KEY `fk_role_has_module_role1_idx` (`role_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_product_category_idx` (`category_id`),
  ADD KEY `location_id` (`location_id`);

--
-- Indexes for table `production`
--
ALTER TABLE `production`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_production_production_status1_idx` (`production_status_id`);

--
-- Indexes for table `production_material`
--
ALTER TABLE `production_material`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_recipie_material_material1_idx` (`material_id`),
  ADD KEY `fk_recipie_material_production1_idx` (`production_id`);

--
-- Indexes for table `production_material_stock`
--
ALTER TABLE `production_material_stock`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_production_has_material_stock_material_stock1_idx` (`material_stock_id`),
  ADD KEY `fk_production_has_material_stock_production1_idx` (`production_id`);

--
-- Indexes for table `production_product`
--
ALTER TABLE `production_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_production_has_product_production1_idx` (`production_id`),
  ADD KEY `fk_production_product_batch1_idx` (`batch_id`);

--
-- Indexes for table `production_status`
--
ALTER TABLE `production_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_return`
--
ALTER TABLE `product_return`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_product_return_user1_idx` (`user_id`),
  ADD KEY `fk_product_return_deliverer1_idx` (`deliverer_id`),
  ADD KEY `fk_product_return_customer1_idx` (`customer_id`),
  ADD KEY `fk_product_return_invoice1_idx` (`invoice_id`);

--
-- Indexes for table `product_return_batch`
--
ALTER TABLE `product_return_batch`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_product_return_has_batch_batch1_idx` (`batch_id`),
  ADD KEY `fk_product_return_has_batch_product_return1_idx` (`product_return_id`),
  ADD KEY `fk_product_return_batch_return_reason1_idx` (`return_reason_id`);

--
-- Indexes for table `product_return_invoice`
--
ALTER TABLE `product_return_invoice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_product_return_has_invoice_invoice1_idx` (`invoice_id`),
  ADD KEY `fk_product_return_has_invoice_product_return1_idx` (`product_return_id`);

--
-- Indexes for table `purchase_order`
--
ALTER TABLE `purchase_order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_purchase_order_supplier1_idx` (`supplier_id`),
  ADD KEY `fk_purchase_order_purchase_order_type1_idx` (`purchase_order_type_id`),
  ADD KEY `fk_purchase_order_user1_idx` (`user_id`),
  ADD KEY `fk_purchase_order_purchase_order_status1_idx` (`purchase_order_status_id`);

--
-- Indexes for table `purchase_order_material`
--
ALTER TABLE `purchase_order_material`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_purchase_order_has_material_material1_idx` (`material_id`),
  ADD KEY `fk_purchase_order_has_material_purchase_order1_idx` (`purchase_order_id`);

--
-- Indexes for table `purchase_order_product`
--
ALTER TABLE `purchase_order_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_purchase_order_has_product_product1_idx` (`product_id`),
  ADD KEY `fk_purchase_order_has_product_purchase_order1_idx` (`purchase_order_id`);

--
-- Indexes for table `purchase_order_status`
--
ALTER TABLE `purchase_order_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchase_order_type`
--
ALTER TABLE `purchase_order_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `remainder`
--
ALTER TABLE `remainder`
  ADD PRIMARY KEY (`id`),
  ADD KEY `repair_id` (`repair_id`),
  ADD KEY `remainder_ibfk_2` (`repair_status`);

--
-- Indexes for table `repaire_device_fault`
--
ALTER TABLE `repaire_device_fault`
  ADD PRIMARY KEY (`id`),
  ADD KEY `repair_id` (`repair_id`),
  ADD KEY `device_fault_id` (`device_fault_id`);

--
-- Indexes for table `repair_collected_accessories`
--
ALTER TABLE `repair_collected_accessories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `collected_accessories` (`collected_accessories`),
  ADD KEY `repair_id` (`repair_id`);

--
-- Indexes for table `repair_possible_solution`
--
ALTER TABLE `repair_possible_solution`
  ADD PRIMARY KEY (`id`),
  ADD KEY `possible_solution_id` (`possible_solution_id`),
  ADD KEY `repair_id` (`repair_id`);

--
-- Indexes for table `repair_status`
--
ALTER TABLE `repair_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `return_reason`
--
ALTER TABLE `return_reason`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `return_table`
--
ALTER TABLE `return_table`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `deliverer_id` (`deliverer_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `route`
--
ALTER TABLE `route`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `target`
--
ALTER TABLE `target`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_target_user1_idx` (`user_id`),
  ADD KEY `fk_target_target_month1_idx` (`target_month_id`);

--
-- Indexes for table `target_month`
--
ALTER TABLE `target_month`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_designation1_idx` (`designation_id`),
  ADD KEY `fk_user_user_status1_idx` (`user_status_id`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_has_role_role1_idx` (`role_id`),
  ADD KEY `fk_user_role_user1_idx` (`user_id`);

--
-- Indexes for table `user_status`
--
ALTER TABLE `user_status`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity`
--
ALTER TABLE `activity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=473;
--
-- AUTO_INCREMENT for table `allocation`
--
ALTER TABLE `allocation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `bank`
--
ALTER TABLE `bank`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `batch`
--
ALTER TABLE `batch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `cheque`
--
ALTER TABLE `cheque`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cheque_status`
--
ALTER TABLE `cheque_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `collected_accessories`
--
ALTER TABLE `collected_accessories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `customer_order`
--
ALTER TABLE `customer_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `customer_order_product`
--
ALTER TABLE `customer_order_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `customer_order_status`
--
ALTER TABLE `customer_order_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `customer_payment`
--
ALTER TABLE `customer_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `daily_expences`
--
ALTER TABLE `daily_expences`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `day_start`
--
ALTER TABLE `day_start`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `deliverer`
--
ALTER TABLE `deliverer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `deliverer_inventory`
--
ALTER TABLE `deliverer_inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `deliverer_user`
--
ALTER TABLE `deliverer_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `designation`
--
ALTER TABLE `designation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `device_fault`
--
ALTER TABLE `device_fault`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `device_model`
--
ALTER TABLE `device_model`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `device_repair`
--
ALTER TABLE `device_repair`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `discription`
--
ALTER TABLE `discription`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `expence_cat`
--
ALTER TABLE `expence_cat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `grn`
--
ALTER TABLE `grn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `grn_material`
--
ALTER TABLE `grn_material`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `grn_product`
--
ALTER TABLE `grn_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `grn_type`
--
ALTER TABLE `grn_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `invoice_condition`
--
ALTER TABLE `invoice_condition`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `invoice_inventory`
--
ALTER TABLE `invoice_inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `invoice_return`
--
ALTER TABLE `invoice_return`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `invoice_return_inventory`
--
ALTER TABLE `invoice_return_inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `invoice_status`
--
ALTER TABLE `invoice_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `invoice_type`
--
ALTER TABLE `invoice_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `job_close`
--
ALTER TABLE `job_close`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `job_close_status`
--
ALTER TABLE `job_close_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `location_number`
--
ALTER TABLE `location_number`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `material`
--
ALTER TABLE `material`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `material_stock`
--
ALTER TABLE `material_stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `module`
--
ALTER TABLE `module`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `payment_cheque`
--
ALTER TABLE `payment_cheque`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `payment_close`
--
ALTER TABLE `payment_close`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `payment_invoice`
--
ALTER TABLE `payment_invoice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `payment_method`
--
ALTER TABLE `payment_method`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `payment_status`
--
ALTER TABLE `payment_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `payment_type`
--
ALTER TABLE `payment_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `petty_cash`
--
ALTER TABLE `petty_cash`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `possible_solution`
--
ALTER TABLE `possible_solution`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `privilege`
--
ALTER TABLE `privilege`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `production`
--
ALTER TABLE `production`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `production_material`
--
ALTER TABLE `production_material`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `production_material_stock`
--
ALTER TABLE `production_material_stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `production_product`
--
ALTER TABLE `production_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `production_status`
--
ALTER TABLE `production_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `product_return`
--
ALTER TABLE `product_return`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `product_return_batch`
--
ALTER TABLE `product_return_batch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `product_return_invoice`
--
ALTER TABLE `product_return_invoice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `purchase_order`
--
ALTER TABLE `purchase_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `purchase_order_material`
--
ALTER TABLE `purchase_order_material`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `purchase_order_product`
--
ALTER TABLE `purchase_order_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `purchase_order_status`
--
ALTER TABLE `purchase_order_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `purchase_order_type`
--
ALTER TABLE `purchase_order_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `remainder`
--
ALTER TABLE `remainder`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `repaire_device_fault`
--
ALTER TABLE `repaire_device_fault`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;
--
-- AUTO_INCREMENT for table `repair_collected_accessories`
--
ALTER TABLE `repair_collected_accessories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `repair_possible_solution`
--
ALTER TABLE `repair_possible_solution`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `repair_status`
--
ALTER TABLE `repair_status`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `return_reason`
--
ALTER TABLE `return_reason`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `return_table`
--
ALTER TABLE `return_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `route`
--
ALTER TABLE `route`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `target`
--
ALTER TABLE `target`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `target_month`
--
ALTER TABLE `target_month`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `user_status`
--
ALTER TABLE `user_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity`
--
ALTER TABLE `activity`
  ADD CONSTRAINT `fk_activity_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `allocation`
--
ALTER TABLE `allocation`
  ADD CONSTRAINT `allocation_ibfk_1` FOREIGN KEY (`repair_id`) REFERENCES `device_repair` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `allocation_ibfk_3` FOREIGN KEY (`batch_id`) REFERENCES `batch` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `batch`
--
ALTER TABLE `batch`
  ADD CONSTRAINT `fk_batch_product1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `cheque`
--
ALTER TABLE `cheque`
  ADD CONSTRAINT `fk_cheque_bank1` FOREIGN KEY (`bank_id`) REFERENCES `bank` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_cheque_cheque_status1` FOREIGN KEY (`cheque_status_id`) REFERENCES `cheque_status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `fk_customer_route1` FOREIGN KEY (`route_id`) REFERENCES `route` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `customer_order`
--
ALTER TABLE `customer_order`
  ADD CONSTRAINT `fk_customer_order_customer_order_status1` FOREIGN KEY (`customer_order_status_id`) REFERENCES `customer_order_status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_order_customer1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_order_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `device_repair`
--
ALTER TABLE `device_repair`
  ADD CONSTRAINT `device_repair_ibfk_1` FOREIGN KEY (`brand_id`) REFERENCES `brand` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `device_repair_ibfk_2` FOREIGN KEY (`repair_status`) REFERENCES `repair_status` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `device_repair_ibfk_3` FOREIGN KEY (`product`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `device_repair_ibfk_4` FOREIGN KEY (`device_model_id`) REFERENCES `device_model` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `device_repair_ibfk_5` FOREIGN KEY (`location_number`) REFERENCES `location_number` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `job_close`
--
ALTER TABLE `job_close`
  ADD CONSTRAINT `job_close_ibfk_1` FOREIGN KEY (`status`) REFERENCES `job_close_status` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `job_close_ibfk_2` FOREIGN KEY (`repair_id`) REFERENCES `device_repair` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `payment_close`
--
ALTER TABLE `payment_close`
  ADD CONSTRAINT `payment_close_ibfk_1` FOREIGN KEY (`repair_id`) REFERENCES `device_repair` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `remainder`
--
ALTER TABLE `remainder`
  ADD CONSTRAINT `remainder_ibfk_1` FOREIGN KEY (`repair_id`) REFERENCES `device_repair` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `remainder_ibfk_2` FOREIGN KEY (`repair_status`) REFERENCES `repair_status` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
