<?php
require_once './../util/initialize.php';
include 'common/upper_content.php';

if (isset($_POST['view']) && isset($_POST['product_return_id'])) {
    $product_return_id=$_POST['product_return_id'];
    if($product_return = ProductReturn::find_by_id($product_return_id)) {
        $product_return_id = trim($_POST['product_return_id']);
        $product_return_batches = ProductReturnBatch::find_all_by_product_return_id($product_return->id);
        $ProductReturnInvoice = ProductReturnInvoice::find_all_by_product_return_id($product_return->id);
    } else {
        Session::set_error("Entry not available...");
        Functions::redirect_to("invoice_management.php");
    }
}
?>
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Invoice Return Details</h3>
            </div>

            <div class="title_right">

            </div>
        </div>

        <div class="clearfix"></div>

        <div class="row">
            <div class="row">

                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_title">

                            <button type="button" id="btn_print" class="btn btn-default" style="float: right;"><i class="glyphicon glyphicon-print"></i>  Print</button>

                            <div class="clearfix"></div>
                        </div>
                        <div class="container" id="divInvoice">
                            <div class="x_content">
                                <div class="col-sm-12">
                                    <div class="col-sm-6" >
                                        <!--                                    <div class="x_title" style="background-color: gray;">
                                                                                <h4 style="color: white;"><b>Invoice Details</b></h4>
                                                                            </div>-->

                                        <table class="table" style="text-align: left;">
                                            <tr>
                                                <td><b>Deliverer :</b></td>
                                                <td id="Ddeliverer"><?= Deliverer::find_by_id($product_return->deliverer_id)->name ?></td>
                                            </tr>
                                            <tr>
                                                <td><b>Date :</b></td>
                                                <td id="date_time"><?= $product_return->date_time ?></td>
                                            </tr>
                                        </table>
                                    </div>
                                    <div class="col-sm-6">
                                        <table class="table" style="text-align: left;">
                                            <tr>
                                                <td><b>Note :</b></td>
                                                <td id="note"><?= $product_return->note ?></td>
                                            </tr>
                                            <tr>
                                                <td><b>USer :</b></td>
                                                <td id="user"><?= User::find_by_id($product_return->user_id)->name; ?></td>

                                            </tr>
                                        </table>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class=" table-responsive" id="table_body" style="border-radius: 5px;margin-top: 15px;">

                                        <div class="x_title" style="background-color: gray;">
                                            <h4 style="color: white;"><b>Returned Product Details</b></h4>
                                        </div>
                                        <hr>
                                        <table class="table table-striped table-bordered">
                                            <thead>
                                            <th>Batch Code</th>
                                            <th>Product</th>
                                            <th>Qty</th>
                                            <th>Unit Price</th>
                                            <th style="text-align: center;">Discount</th>
                                            <th>Line Total</th>
                                            <th>Reason</th>
                                            </thead>
                                            <tbody id="tbl">
                                                <?php
                                                $return_total = 0;
                                                foreach ($product_return_batches as $data) {
                                                    $product_id = Batch::find_by_id($data->batch_id)->product_id;
                                                    $product_name = Product::find_by_id($product_id)->name;

                                                    $linetotal  = 0;
                                                    $dis = 0;

                                                    $dis = 100 - $data->discount;
                                                    $dis = $dis/100;
                                                    $linetotal = $data->unit_price*$data->qty*$dis;

                                                    ?>
                                                    <tr>
                                                        <td><?= Batch::find_by_id($data->batch_id)->code; ?></td>
                                                        <td><?= $product_name ?></td>
                                                        <td><?= $data->qty ?></td>
                                                        <td style="text-align: right;"><?= number_format($data->unit_price,2) ?></td>
                                                        <td style="text-align: center;"><?= $data->discount ?>%</td>                                                        
                                                        <td style="text-align: right;"><?= number_format($linetotal,2) ?></td>
                                                        <td><?= ReturnReason::find_by_id($data->return_reason_id)->name ?></td>
                                                    </tr>    
                                                    <?php
                                                    $return_total = $return_total + ($linetotal);
                                                }

                                                echo "<tr style='color:white;background-color:teal;'>";
                                                    echo "<td style='text-align:right;' colspan='5'>TOTAL: </td>";
                                                    echo "<td style='text-align: right;'><b>".number_format($return_total,2)."<b></td>";
                                                    echo "<td></td>";
                                                    echo "</tr>";
                                                ?>    

                                            </tbody>
                                        </table>
                                    </div>
                                </div>


                                <div class="col-sm-12">
                                    <div class=" table-responsive" id="table_body" style="border-radius: 5px;margin-top: 15px;">

                                        <div class="x_title" style="background-color: gray;">
                                            <h4 style="color: white;"><b>Returned Invoice Details</b></h4>
                                        </div>
                                        <hr>
                                        <table class="table table-striped table-bordered">
                                            <thead>
                                            <th>Invoice Number</th>
                                            <th>Customer Name</th>
                                            <th style='text-align: right;'>Return Amount</th>
                                            
                                            </thead>
                                            <tbody id="tbl">
                                                <?php
                                                $total = 0;
                                                foreach ($ProductReturnInvoice as $data) {
                                                    echo "<tr>";
                                                    echo "<td>".$data->invoice_id()->code."</td>";
                                                    echo "<td>".$data->invoice_id()->customer_id()->name."</td>";
                                                    echo "<td style='text-align:right;'>".number_format($data->return_amount,2)."</td>";
                                                    echo "</tr>";
                                                    $total = $total + $data->return_amount;
                                                }

                                                    echo "<tr style='color:white;background-color:teal;'>";
                                                    echo "<td style='text-align:right;' colspan='2'>TOTAL: </td>";
                                                    echo "<td style='text-align: right;'><b>".number_format($total,2)."<b></td>";
                                                    echo "</tr>";

                                                ?>    

                                            </tbody>
                                        </table>
                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<?php include 'common/bottom_content.php'; ?>
<script>
    $('#btn_print').click(function () {
//     
        PrintDiv();
    });

    function PrintDiv() {
        var divToPrint = document.getElementById('divInvoice');
        var popupWin = window.open('', '_blank', 'width=800,height=500');
        popupWin.document.open();
        popupWin.document.write('<html><head><link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet"></head><body onload="window.print()"><br/><h3 style="text-align:center;">Return Invoice Report</h3><hr><br/><div>' + divToPrint.innerHTML + '</div></body></html>');
        popupWin.document.close();
    }
</script>