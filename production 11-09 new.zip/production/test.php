<?php
ini_set('display_errors', 1);
require_once './../util/initialize.php';

// print_r($_SESSION["product_return_invoice"]);
print_r($_SESSION["transfer_return_item"]);
// print_r($_SESSION["product_return_item"]);


// print_r($_SESSION["return_deliverer"]);
// print_r($_SESSION["return_date_time"]);
// print_r($_SESSION["return_return_note"]);

// unset($_SESSION['product_return_invoice']);