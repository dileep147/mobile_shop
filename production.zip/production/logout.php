<?php
    require_once './../util/initialize.php';
    Session::logout_and_redirect();
    
?>