<?php
require_once './../util/initialize.php';
include 'common/upper_content.php';

if (!(isset($_POST["id"]))) {
  $supplier = new Supplier();
}else{
  $supplier = Supplier::find_by_id($_POST["id"]);
}
?>

<!--page content-->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
      </div>

      <div class="title_right">

      </div>
    </div>

    <div class="clearfix"></div>

    <?php Functions::output_result(); ?>

    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel" style="background-color:#ecf0f1;">
          <div class="x_title">
            <h2 id="title" style="font-weight:700;"><?php echo (empty($supplier->id)) ? 'Add' : 'Edit'; ?> Device Repair:</h2>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <form id="formSupplier" action="proccess/supplier_proccess.php" method="post" class="form-horizontal form-label-left" >
              <div class="col-md-12 col-sm-12 col-xs-12">
                <input type="hidden" class="form-control" id="txtId" name="id" value="<?php echo $supplier->id; ?>" />

                <div class="col-md-4 col-sm-4 col-xs-6 ">
                  <div class="form-group">
                    <label>Job No:</label>
                    <input type="text" class="form-control" placeholder="Job No" id="txtName" name="name" value="JOB-0001" required="" autofocus='on'>
                  </div>
                </div>

                <div class="col-md-4 col-sm-4 col-xs-6 ">
                  <div class="form-group">
                    <label>Job Date:</label>
                    <input type="text" class="form-control" placeholder="Job Date" id="txtName" name="name" required="">
                  </div>
                </div>

                <div class="col-md-4 col-sm-4 col-xs-6 ">
                  <div class="form-group">
                    <label>System Date:</label>
                    <input type="text" class="form-control" placeholder="System Date" id="txtName" name="name" value="<?php echo date("Y-m-d h:i:sa"); ?>" required="" disabled>
                  </div>
                </div>

                <div class="col-md-9 col-sm-9 col-xs-12">
                  <div class="form-group">
                    <label>Customer Name:</label>
                    <textarea class="form-control" name="" ></textarea>
                  </div>
                </div>

                <div class="col-md-4 col-sm-4 col-xs-6 ">
                  <div class="form-group">
                    <label>ID Number:</label>
                    <input type="text" class="form-control" placeholder="ID Number" name="name" value="" required="">
                  </div>
                </div>

                <div class="col-md-4 col-sm-4 col-xs-6 ">
                  <div class="form-group">
                    <label>Contact Number:</label>
                    <input type="text" class="form-control" placeholder="Contact Number" name="name" value="" required="">
                  </div>
                </div>


                <div class="col-md-9 col-sm-9 col-xs-6 ">
                  <div class="form-group">
                    <label>Delivery Date:</label>
                    <input type="text" class="form-control" placeholder="Delivery Date" name="name" value="" required="">
                  </div>
                </div>

                <div class="col-md-9 col-sm-9 col-xs-6 ">
                  <div class="form-group">
                    <label>Device Name & Model Number:</label>
                    <input type="text" class="form-control" placeholder="Delivery Name & Model Number" name="name" value="" required="">
                  </div>
                </div>

                <div class="col-md-9 col-sm-9 col-xs-6 ">
                  <div class="form-group">
                    <label>Device Location & Number:</label>
                    <input type="text" class="form-control" placeholder="Device Location & Number" name="name" value="" required="">
                  </div>
                </div>

                <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group">
                    <label>Device Fault:</label>
                    <!-- <textarea class="form-control" name="" ></textarea> -->
                    <br/>
                    <?php
                    foreach(DeviceFault::find_all() as $data){
                      echo ' <label><input type="checkbox" value=""> '.$data->name.'</label>';
                    }
                    ?>
                  </div>
                </div>

                <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group">
                    <label>Possible Solution:</label>
                    <!-- <textarea class="form-control" name="" ></textarea> -->
                    <br/>
                    <?php
                    foreach(PossibleSolution::find_all() as $data){
                      echo ' <label><input type="checkbox" value=""> '.$data->name.'</label>';
                    }
                    ?>
                  </div>
                </div>


                <div class="col-md-12 col-sm-12 col-xs-12" style="min-height:100px;">
                  <div class="form-group">
                    <label>Collected Accessories:</label>
                    <!-- <textarea class="form-control" name=""  rows="7"></textarea> -->
                    <br/>
                    <?php
                    foreach(CollectedAccessories::find_all() as $data){
                      echo ' <label><input type="checkbox" value=""> '.$data->name.'</label>';
                    }
                    ?>
                  </div>
                </div>



                <div class="col-md-7 col-sm-7 col-xs-12 ">
                  <div class="form-group">
                    <label>Job Cost (LKR):</label>
                    <input type="text" class="form-control" placeholder="JOB COST" name="name" value="0.00" required="">
                  </div>
                </div>

                <div class="col-md-7 col-sm-7 col-xs-12 ">
                  <div class="form-group">
                    <label>Advanced Payment (LKR):</label>
                    <input type="text" class="form-control" placeholder="ADVANCED PAYMENT" name="name" value="0.00" required="">
                  </div>
                </div>

                <div class="col-md-7 col-sm-7 col-xs-12 ">
                  <div class="form-group">
                    <label>Balance Payment (LKR):</label>
                    <input type="text" class="form-control" placeholder="ADVANCED PAYMENT" name="name" value="0.00" required="" disabled>
                  </div>
                </div>



                <div class="modal-footer col-md-12 col-sm-12 col-xs-12">
                  <div class=" col-md-6 col-sm-6 col-xs-12">
                    <button id="btnSave" type="button" name="save" class="btn btn-block btn-success"><i class="fa fa-floppy-o"></i> Save</button>
                  </div>
                  <div class=" col-md-6 col-sm-6 col-xs-12">
                    <a href="#"><button type="button" name="reset" class="btn btn-block btn-primary"><i class="fa fa-history"></i> Reset</button></a>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--/page content-->
<?php include 'common/bottom_content.php'; ?>

<script>


</script>
