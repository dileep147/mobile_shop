<?php include './common/upper_content.php'; ?><!-- upper content -->
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Activity Log</h3>
            </div>

            <div class="title_right">
            </div>
        </div>

        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Plain Page<small>Small text</small></h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <table id="datatable-fixed-header" class="table table-striped">
                            <thead>
                                <tr>
                                    <th >User</th>
                                    <th >Designation</th>
                                    <th >Activity</th>
                                    <th >Time</th>
                                    <th >Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <div class="col-md-12">
                                            <img src="images/img.jpg" class="avatar" alt="Avatar">
                                        </div>
                                        <div class="col-md-12">
                                            Muditha Priyanka
                                        </div>
                                    </td>
                                    <td>Rep</td>
                                    <td><h4>Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua butcher retro keffiyeh dreamcatcher synth.</h4></td>
                                    <td>09.00am</td>
                                    <td>24/05/2017</td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="col-md-12">
                                            <img src="images/img.jpg" class="avatar" alt="Avatar">
                                        </div>
                                        <div class="col-md-12">
                                            John Doe
                                        </div>
                                    </td>
                                    <td>Distributor</td>
                                    <td><h4>Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua butcher retro keffiyeh dreamcatcher synth.</h4></td>
                                    <td>09.00am</td>
                                    <td>24/05/2017</td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="col-md-12">
                                            <img src="images/img.jpg" class="avatar" alt="Avatar">
                                        </div>
                                        <div class="col-md-12">
                                            John Doe
                                        </div>
                                    </td>
                                    <td>Distributor</td>
                                    <td><h4>Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua butcher retro keffiyeh dreamcatcher synth.</h4></td>
                                    <td>09.00am</td>
                                    <td>24/05/2017</td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="col-md-12">
                                            <img src="images/img.jpg" class="avatar" alt="Avatar">
                                        </div>
                                        <div class="col-md-12">
                                            John Doe
                                        </div>
                                    </td>
                                    <td>Distributor</td>
                                    <td><h4>Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua butcher retro keffiyeh dreamcatcher synth.</h4></td>
                                    <td>09.00am</td>
                                    <td>24/05/2017</td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="col-md-12">
                                            <img src="images/img.jpg" class="avatar" alt="Avatar">
                                        </div>
                                        <div class="col-md-12">
                                            Kamal Perera
                                        </div>
                                    </td>
                                    <td>Admin</td>
                                    <td><h4>Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua butcher retro keffiyeh dreamcatcher synth.</h4></td>
                                    <td>09.00am</td>
                                    <td>24/05/2017</td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="col-md-12">
                                            <img src="images/img.jpg" class="avatar" alt="Avatar">
                                        </div>
                                        <div class="col-md-12">
                                            John Doe
                                        </div>
                                    </td>
                                    <td>Distributor</td>
                                    <td><h4>Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua butcher retro keffiyeh dreamcatcher synth.</h4></td>
                                    <td>09.00am</td>
                                    <td>24/05/2017</td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="col-md-12">
                                            <img src="images/img.jpg" class="avatar" alt="Avatar">
                                        </div>
                                        <div class="col-md-12">
                                            Kamal Perera
                                        </div>
                                    </td>
                                    <td>Admin</td>
                                    <td><h4>Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua butcher retro keffiyeh dreamcatcher synth.</h4></td>
                                    <td>09.00am</td>
                                    <td>24/05/2017</td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="col-md-12">
                                            <img src="images/img.jpg" class="avatar" alt="Avatar">
                                        </div>
                                        <div class="col-md-12">
                                            Kamal Perera
                                        </div>
                                    </td>
                                    <td>Admin</td>
                                    <td><h4>Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua butcher retro keffiyeh dreamcatcher synth.</h4></td>
                                    <td>09.00am</td>
                                    <td>24/05/2017</td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="col-md-12">
                                            <img src="images/img.jpg" class="avatar" alt="Avatar">
                                        </div>
                                        <div class="col-md-12">
                                            John Doe
                                        </div>
                                    </td>
                                    <td>Distributor</td>
                                    <td><h4>Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua butcher retro keffiyeh dreamcatcher synth.</h4></td>
                                    <td>09.00am</td>
                                    <td>24/05/2017</td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="col-md-12">
                                            <img src="images/img.jpg" class="avatar" alt="Avatar">
                                        </div>
                                        <div class="col-md-12">
                                            Muditha Priyanka
                                        </div>
                                    </td>
                                    <td>Rep</td>
                                    <td><h4>Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua butcher retro keffiyeh dreamcatcher synth.</h4></td>
                                    <td>09.00am</td>
                                    <td>24/05/2017</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /page content -->
<?php include './common/bottom_content.php'; ?><!-- bottom content -->