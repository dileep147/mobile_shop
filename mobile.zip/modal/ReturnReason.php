<?php
require_once __DIR__.'/../util/initialize.php';

class ReturnReason extends DatabaseObject{
    protected static $table_name="return_reason";
    protected static $db_fields=array(); 
    protected static $db_fk=array();
}

?>