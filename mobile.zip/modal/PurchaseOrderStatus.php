<?php
require_once __DIR__.'/../util/initialize.php';

class PurchaseOrderStatus extends DatabaseObject{
    protected static $table_name="purchase_order_status";
    protected static $db_fields=array(); 
    protected static $db_fk=array();
    
//    public $id;
//    public $name;
}

?>