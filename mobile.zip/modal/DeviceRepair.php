<?php

require_once __DIR__ . '/../util/initialize.php';

class DeviceRepair extends DatabaseObject {

    protected static $table_name = "device_repair";
    protected static $db_fields = array();
    protected static $db_fk = array("device_model_id" => "DeviceModel","location_number" => "LocationNumber","brand_id" => "Brand","repair_status" => "RepairStatus","product"=>"Product");


    public function device_model_id() {
        return parent::get_fk_object("device_model_id");
    }


    public function location_number() {
      return parent::get_fk_object("location_number");
    }

    public function brand_id() {
      return parent::get_fk_object("brand_id");
    }

    public function repair_status() {
      return parent::get_fk_object("repair_status");
    }
     public function product() {
      return parent::get_fk_object("product");
    }
    
}

?>
