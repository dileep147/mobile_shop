<footer>
    <div class="pull-right">
        <b><?php echo ProjectConfig::$project_name; ?></b> - Control panel by <a href="https://www.facebook.com/aitlab.lk/" target='_blank'>aitsoft©</a>
    </div>
    <div class="clearfix"></div>
</footer>
