<?php
require_once  __DIR__.'/../util/initialize.php';

class Brand extends DatabaseObject{
    protected static $table_name="brand";
    protected static $db_fields=array();
    protected static $db_fk=array();
}
