<?php
require_once __DIR__.'/../util/initialize.php';

class InvoiceStatus extends DatabaseObject{
    protected static $table_name="invoice_status";
    protected static $db_fields=array();
    protected static $db_fk=array();
    
//    public $id;
//    public $name;
}

?>