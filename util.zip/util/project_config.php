<?php

class ProjectConfig {

  public static $project_name = " ISHARA COMPUTERS & D.J.CLUB ";
  public static $address = " ISHARA COMPUTERS & D.J.CLUB ";
  public static $tel = " Phone: 031 12 34 567 / 077 12 34 567 ";
  public static $address_arr = array(" ISHARA COMPUTERS & D.J.CLUB ", "Address 1", "Address 2", "Address 3", "Address 4");
  public static $tel_arr = array(" 033 22 70 922 ", " 077 30 02 600 ");
  public static $address_html = "<strong> ISHARA COMPUTERS & D.J.CLUB </strong> , <br/> Address,<br/>Address,<br/>Address. ";
  public static $tel_html = "<strong> Phone: </strong> 033 12 34 567 / 077 12 34 567 ";

//    public static $modules = array(
//        "user" => "User",
//        "privilege" => "Privilege",
//        "designation" => "Designation",
//        "target" => "Target",
//        "category" => "Category",
//        "product" => "Product",
//        "batch" => "Batch",
//        "material" => "Material",
//        "production_plan" => "Production Plan",
//        "production" => "Production",
//        "supplier" => "Supplier",
//        "customer" => "Customer",
//        "route" => "Route",
//        "product_po" => "Product PO",
//        "material_po" => "Material PO",
//        "product_po" => "Product GRN",
//        "material_po" => "Material GRN",
//        "invoice" => "Invoice",
//        "payment" => "Payment",
//        "return" => "Return",
//        "deliverer" => "Deliverer",
//        "deliverer_inventory" => "Deliverer Inventory"
//    );
}
