<?php
require_once __DIR__.'/../util/initialize.php';

class GRNType extends DatabaseObject{
    protected static $table_name="grn_type";
    protected static $db_fields=array(); 
    protected static $db_fk=array();
    
//    public $id;
//    public $name;
}

?>