<?php

class ProjectConfig {

    public static $project_name = "BILLING SYSTEM";
    public static $address = "Address";
    public static $tel = "Phone: 077 2880388 / 077 8243745";
    public static $address_arr = array("BILLING SYSTEM", "Address1", "Address2", "Address3", "Address4");
    public static $tel_arr = array("077 2880388", "077 8243745");
    public static $address_html = "<strong> BILLING SYSTEM</strong>,<br/>Address1,<br/>Address2,<br/>Address3,<br/>Address4.";
    public static $tel_html = "<strong>Phone:</strong> 077 2880388 / 077 8243745";

//    public static $modules = array(
//        "user" => "User",
//        "privilege" => "Privilege",
//        "designation" => "Designation",
//        "target" => "Target",
//        "category" => "Category",
//        "product" => "Product",
//        "batch" => "Batch",
//        "material" => "Material",
//        "production_plan" => "Production Plan",
//        "production" => "Production",
//        "supplier" => "Supplier",
//        "customer" => "Customer",
//        "route" => "Route",
//        "product_po" => "Product PO",
//        "material_po" => "Material PO",
//        "product_po" => "Product GRN",
//        "material_po" => "Material GRN",
//        "invoice" => "Invoice",
//        "payment" => "Payment",
//        "return" => "Return",
//        "deliverer" => "Deliverer",
//        "deliverer_inventory" => "Deliverer Inventory"
//    );
}
