<pre>
<?php
ini_set('display_errors', 1);
require_once './../util/initialize.php';

print_r($_SESSION["invoice_item_grid"]);

?>
</pre>
