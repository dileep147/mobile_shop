<?php
require_once './../util/initialize.php';
echo "<pre>";
// print_r($_SESSION['item_batch_barcode']);
print_r($_SESSION["item_grid"]);
echo "</pre>";
// unset($_SESSION['item_batch_barcode']);

?>
