<?php
    header("Location: production/index.php");
//    echo "akjjshakls";
?>